# ProGuard rules for Secure Chat
# Enable R8 code shrinking and obfuscation for release builds

# Flutter
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-keep class com.google.firebase.** { *; }
-dontwarn io.flutter.embedding.**

# JSON serialization
-keepclassmembers class * {
  @com.google.gson.annotations.SerializedName <fields>;
}

# Rust FFI
-keep class com.cunarist.rust_bridge.** { *; }

# Secure Storage
-keep class com.it_nomads.fluttersecurestorage.** { *; }

# BLE
-keep class com.boskokg.flutter_blue_plus.** { *; }

# SQLite
-keep class net.sqlcipher.** { *; }
-dontwarn net.sqlcipher.**

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int i(...);
    public static int w(...);
    public static int d(...);
    public static int e(...);
}

# Crypto
-keepclassmembers class * {
    native <methods>;
}
