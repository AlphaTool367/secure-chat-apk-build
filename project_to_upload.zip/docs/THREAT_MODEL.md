# Threat Model - Secure Chat

## STRIDE Analysis

### Spoofing
- **Threat**: Attacker impersonates a legitimate user
- **Mitigation**: Ed25519 digital signatures on all messages; TOFU with explicit verification via SAS/QR fingerprint
- **Residual Risk**: Social engineering attacks; user must verify fingerprints

### Tampering
- **Threat**: Message modification in transit or at rest
- **Mitigation**: ChaCha20-Poly1305 authenticated encryption; BLAKE2b hash verification for media
- **Residual Risk**: Zeroized after decryption in memory

### Repudiation
- **Threat**: User denies sending a message
- **Mitigation**: Ed25519 signatures provide non-repudiation per message
- **Note**: Anonymous identity means legal attribution is intentionally impossible

### Information Disclosure
- **Threat**: Message content, metadata, or key material leaks
- **Mitigation**: 
  - E2EE with forward secrecy (Double Ratchet)
  - Encrypted at rest (AES-256-GCM)
  - Metadata padding and timestamp jitter
  - No cloud sync or telemetry
  - OS secure enclave for key storage
- **Residual Risk**: Screen capture, shoulder surfing

### Denial of Service
- **Threat**: Prevent communication via jamming or resource exhaustion
- **Mitigation**: Store-and-forward queue; mesh relay fallback; message retry with backoff
- **Residual Risk**: Physical radio jamming (requires close proximity)

### Elevation of Privilege
- **Threat**: Malicious plugin gains unauthorized access
- **Mitigation**: 
  - Plugin sandboxing in isolates
  - Permission manifest enforced at load time
  - Cryptographic signature verification
  - No plugin access to raw key material
- **Residual Risk**: Zero-day in Flutter/Dart runtime

## Attack Scenarios

### Scenario 1: Device Compromise
An attacker gains root access to a device.
- **Impact**: Can read decrypted messages in memory, extract SQLite databases
- **Mitigation**: 
  - Root/jailbreak detection refuses to run on compromised devices
  - Memory zeroization minimizes exposure window
  - Encrypted DB requires master key from secure enclave

### Scenario 2: Man-in-the-Middle
An attacker intercepts initial key exchange.
- **Impact**: Can decrypt all future messages
- **Mitigation**: 
  - Fingerprint verification required before first message
  - Key change detection alerts user
  - SAS verbal verification for high-security contacts

### Scenario 3: Passive Traffic Analysis
An attacker observes network patterns without decrypting content.
- **Impact**: Can infer communication patterns, contact graphs
- **Mitigation**: 
  - Constant-size padding (256-byte blocks)
  - Timestamp jitter (±30 seconds)
  - Route randomization via mesh
  - No persistent connection to central server

### Scenario 4: Supply Chain Attack
Attacker compromises app distribution or dependencies.
- **Impact**: Malicious code runs with full privileges
- **Mitigation**: 
  - Reproducible builds
  - Dependency pinning with hash verification
  - Open source for community audit
  - F-Droid or direct APK distribution (no app store intermediary)

## Cryptographic Specification

### Key Hierarchy
```
Master Key (OS Enclave / Argon2id)
├── Identity Key (Ed25519 + X25519)
│   └── Per-peer Shared Secret (X25519 ECDH)
│       └── Root Key (HKDF-SHA256)
│           ├── Sending Chain Key
│           │   └── Message Keys (HKDF)
│           └── Receiving Chain Key
│               └── Message Keys (HKDF)
└── Storage Key (AES-256-GCM)
    ├── Chat Databases
    ├── Media Vault
    └── Config Files
```

### Algorithm Selection Rationale
| Algorithm | Purpose | Rationale |
|-----------|---------|-----------|
| Ed25519 | Identity signatures | Fast, compact, side-channel resistant |
| X25519 | ECDH key exchange | Constant-time, widely audited |
| ChaCha20-Poly1305 | Message encryption | Faster than AES on mobile, constant-time |
| Argon2id | Key derivation | Memory-hard, GPU/ASIC resistant |
| BLAKE2b | Hashing | Faster than SHA-3, built-in keyed mode |
| HKDF-SHA256 | Key derivation | Standard, well-analyzed |

## Memory Security
- All key material uses `zeroize` crate for secure cleanup
- Secrets wrapped in `Secret<T>` to prevent accidental logging
- Rust core prevents buffer overflows via memory safety
- No `unsafe` code in core library
- Stack canaries enabled in release builds

## Audit Checklist
- [ ] Independent cryptographic audit (Cure53 or Trail of Bits)
- [ ] Fuzz testing on message parser
- [ ] Side-channel analysis (timing, power, cache)
- [ ] Penetration testing on Flutter layer
- [ ] Dependency vulnerability scan
- [ ] Reproducible build verification
