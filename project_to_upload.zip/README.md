# Secure Chat

Offline-First, Zero-DB, Zero-Signup, Fully Anonymous & Secure Chat Application

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        USER DEVICE                           │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────────┐ │
│  │   UI Layer   │  │  Plugin Hub    │  │  Secure Storage    │ │
│  │ (Flutter)    │◄─┤ (Isolates)    │◄─ (Encrypted Files) │ │
│  └──────┬──────┘  └──────┬───────┘  └─────────┬──────────┘ │
│         │                │                    │            │
│  ┌──────▼────────────────▼────────────────────▼──────────┐│
│  │                  CORE ENGINE (Rust)                     ││
│  │  • Crypto (X25519, ChaCha20, Ed25519)                  ││
│  │  • P2P Networking (BLE / Wi-Fi Direct / libp2p)       ││
│  │  • Message Routing & Forward Secrecy                 ││
│  │  • Media Chunking & Encryption                       ││
│  └───────────────────────┬───────────────────────────────┘│
│                          │                                 │
│  ┌───────────────────────▼───────────────────────────────┐ │
│  │              HARDWARE / OS SECURITY                   │ │
│  │  • Android Keystore / iOS Secure Enclave              │ │
│  │  • Sandboxing • Memory Protection • Root Detection    │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Features

- **Zero Central Server**: All logic runs locally or peer-to-peer
- **Zero Signup**: Identity generated on first launch, stored encrypted
- **Zero Database**: Pure file-based storage with optional local SQLite for indexing
- **End-to-End Encryption**: Signal Double Ratchet with forward secrecy
- **Multiple Transport Modes**: BLE, Wi-Fi Direct, Mesh, libp2p, Tor
- **Plugin Architecture**: Modular, sandboxed, signed extensions
- **No Telemetry**: No analytics, crash reporting, or cloud sync

## Quick Start

### Prerequisites
- Flutter 3.24+
- Rust 1.80+
- Android SDK 34 / Xcode 15

### Setup

```bash
# Clone repository
git clone https://github.com/securechat/core.git
cd secure_chat

# Install Rust dependencies
cd native/rust
cargo build --release
cd ../..

# Generate FFI bridge
flutter_rust_bridge_codegen generate

# Install Flutter dependencies
flutter pub get

# Run on device
flutter run
```

### Building Release

```bash
# Android APK
flutter build apk --release

# Android App Bundle
flutter build appbundle --release

# iOS
flutter build ios --release
```

## Security

See [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md) for the complete threat model and cryptographic specification.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| UI | Flutter (Dart) |
| Core Crypto/Net | Rust + FFI |
| Local Storage | Encrypted SQLite + Binary Files |
| Key Storage | flutter_secure_storage + OS Enclave |
| P2P Offline | flutter_blue_plus, wifi_iot |
| P2P Online | libp2p-rs + DHT |

## License

GPL-3.0

## Contributing

See CONTRIBUTING.md for guidelines.
