//! Utility functions and security helpers
//! 
//! # Features
//! - Memory zeroization helpers
//! - Constant-time comparison
//! - Timestamp jitter for metadata obfuscation
//! - Root/jailbreak detection stubs

use crate::SecureChatError;
use rand::Rng;

/// Zeroize a memory buffer
pub fn secure_zero(buf: &mut [u8]) {
    use zeroize::Zeroize;
    buf.zeroize();
}

/// Add random jitter to timestamp (±30 seconds) to prevent timing analysis
pub fn jitter_timestamp(timestamp: u64) -> u64 {
    let mut rng = rand::thread_rng();
    let jitter = rng.gen_range(0..60) as i64 - 30;
    let result = timestamp as i64 + jitter;
    result.max(0) as u64
}

/// Pad payload to obfuscate size (pad to next 256-byte boundary)
pub fn pad_payload(data: &[u8]) -> Vec<u8> {
    let block_size = 256;
    let padded_len = ((data.len() / block_size) + 1) * block_size;
    let padding = padded_len - data.len();
    
    let mut result = Vec::with_capacity(padded_len);
    result.extend_from_slice(data);
    result.extend(std::iter::repeat(0u8).take(padding));
    result
}

/// Detect if device might be rooted/jailbroken (stub - real impl uses platform APIs)
pub fn detect_compromised_device() -> DeviceSecurityStatus {
    // In real implementation:
    // - Android: Check for su binary, Magisk, unlocked bootloader
    // - iOS: Check for Cydia, unsigned code execution, sandbox escape
    // - Emulator detection via hardware checks
    DeviceSecurityStatus {
        is_rooted: false, // Placeholder
        is_emulator: false,
        has_tamper_evidence: false,
        security_level: SecurityLevel::Standard,
    }
}

/// Device security assessment
#[derive(Debug, Clone)]
pub struct DeviceSecurityStatus {
    pub is_rooted: bool,
    pub is_emulator: bool,
    pub has_tamper_evidence: bool,
    pub security_level: SecurityLevel,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum SecurityLevel {
    Secure = 0,       // Hardware-backed, no root
    Standard = 1,     // Normal device
    Compromised = 2,  // Rooted/jailbroken but usable with warning
    Untrusted = 3,    // Critical compromise - refuse to run
}

/// Verify app integrity (anti-tamper)
pub fn verify_app_integrity() -> Result<(), SecureChatError> {
    // Check code signature, checksums of critical libraries
    // Real impl uses platform attestation APIs
    Ok(())
}

/// Generate a unique nonce for each operation
pub fn generate_nonce() -> Vec<u8> {
    use rand::RngCore;
    let mut buf = vec![0u8; 24];
    rand::thread_rng().fill_bytes(&mut buf);
    buf
}
