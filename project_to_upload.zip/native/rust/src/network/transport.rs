//! Transport abstractions for all P2P modes
//! 
//! Each transport implements this interface for unified handling

use crate::SecureChatError;
use crate::network::ConnectionState;
use async_trait::async_trait;
use serde::{Serialize, Deserialize};

/// Generic transport interface
#[async_trait]
pub trait Transport: Send + Sync {
    /// Transport identifier
    fn id(&self) -> &str;
    
    /// Supported network mode
    fn mode(&self) -> super::NetworkMode;
    
    /// Initialize the transport (start listeners, etc.)
    async fn init(&mut self) -> Result<(), SecureChatError>;
    
    /// Start discovery/advertisement
    async fn start_discovery(&mut self) -> Result<(), SecureChatError>;
    
    /// Stop discovery
    async fn stop_discovery(&mut self) -> Result<(), SecureChatError>;
    
    /// Connect to a specific peer
    async fn connect(&mut self, peer_id: &str, address: &str) -> Result<(), SecureChatError>;
    
    /// Disconnect from peer
    async fn disconnect(&mut self, peer_id: &str) -> Result<(), SecureChatError>;
    
    /// Send data to connected peer
    async fn send(&mut self, peer_id: &str, data: &[u8]) -> Result<(), SecureChatError>;
    
    /// Receive data (returns peer_id and data)
    async fn receive(&mut self) -> Result<(String, Vec<u8>), SecureChatError>;
    
    /// Get connection state for a peer
    fn connection_state(&self, peer_id: &str) -> ConnectionState;
    
    /// Shutdown transport completely
    async fn shutdown(&mut self) -> Result<(), SecureChatError>;
}

/// BLE transport implementation (stub for Flutter bridge integration)
pub struct BleTransport {
    pub device_id: String,
    pub state: ConnectionState,
    pub connected_peers: std::collections::HashMap<String, ConnectionState>,
}

impl BleTransport {
    pub fn new(device_id: String) -> Self {
        Self {
            device_id,
            state: ConnectionState::Disconnected,
            connected_peers: std::collections::HashMap::new(),
        }
    }
}

#[async_trait]
impl Transport for BleTransport {
    fn id(&self) -> &str { "ble" }
    fn mode(&self) -> super::NetworkMode { super::NetworkMode::BleDirect }
    
    async fn init(&mut self) -> Result<(), SecureChatError> {
        // BLE init delegated to Flutter via FFI (platform-specific)
        self.state = ConnectionState::Discovering;
        Ok(())
    }
    
    async fn start_discovery(&mut self) -> Result<(), SecureChatError> {
        self.state = ConnectionState::Discovering;
        Ok(())
    }
    
    async fn stop_discovery(&mut self) -> Result<(), SecureChatError> {
        if self.state == ConnectionState::Discovering {
            self.state = ConnectionState::Disconnected;
        }
        Ok(())
    }
    
    async fn connect(&mut self, peer_id: &str, _address: &str) -> Result<(), SecureChatError> {
        self.connected_peers.insert(peer_id.to_string(), ConnectionState::Connecting);
        // Actual BLE connection managed by Flutter layer
        Ok(())
    }
    
    async fn disconnect(&mut self, peer_id: &str) -> Result<(), SecureChatError> {
        self.connected_peers.remove(peer_id);
        Ok(())
    }
    
    async fn send(&mut self, peer_id: &str, data: &[u8]) -> Result<(), SecureChatError> {
        if !self.connected_peers.contains_key(peer_id) {
            return Err(SecureChatError::Network(format!("Peer {} not connected via BLE", peer_id)));
        }
        // Data queued to Flutter BLE layer
        Ok(())
    }
    
    async fn receive(&mut self) -> Result<(String, Vec<u8>), SecureChatError> {
        // Blocking receive - in real impl uses channels from Flutter
        Err(SecureChatError::Network("BLE receive requires Flutter integration".into()))
    }
    
    fn connection_state(&self, peer_id: &str) -> ConnectionState {
        self.connected_peers.get(peer_id).copied().unwrap_or(ConnectionState::Disconnected)
    }
    
    async fn shutdown(&mut self) -> Result<(), SecureChatError> {
        self.connected_peers.clear();
        self.state = ConnectionState::Disconnected;
        Ok(())
    }
}

/// Wi-Fi Direct transport
pub struct WifiDirectTransport {
    pub device_id: String,
    pub connected_peers: std::collections::HashMap<String, ConnectionState>,
}

impl WifiDirectTransport {
    pub fn new(device_id: String) -> Self {
        Self {
            device_id,
            connected_peers: std::collections::HashMap::new(),
        }
    }
}

#[async_trait]
impl Transport for WifiDirectTransport {
    fn id(&self) -> &str { "wifi_direct" }
    fn mode(&self) -> super::NetworkMode { super::NetworkMode::WifiDirect }
    
    async fn init(&mut self) -> Result<(), SecureChatError> { Ok(()) }
    async fn start_discovery(&mut self) -> Result<(), SecureChatError> { Ok(()) }
    async fn stop_discovery(&mut self) -> Result<(), SecureChatError> { Ok(()) }
    async fn connect(&mut self, peer_id: &str, _address: &str) -> Result<(), SecureChatError> {
        self.connected_peers.insert(peer_id.to_string(), ConnectionState::Connected);
        Ok(())
    }
    async fn disconnect(&mut self, peer_id: &str) -> Result<(), SecureChatError> {
        self.connected_peers.remove(peer_id);
        Ok(())
    }
    async fn send(&mut self, _peer_id: &str, _data: &[u8]) -> Result<(), SecureChatError> { Ok(()) }
    async fn receive(&mut self) -> Result<(String, Vec<u8>), SecureChatError> {
        Err(SecureChatError::Network("WiFi Direct receive requires Flutter integration".into()))
    }
    fn connection_state(&self, peer_id: &str) -> ConnectionState {
        self.connected_peers.get(peer_id).copied().unwrap_or(ConnectionState::Disconnected)
    }
    async fn shutdown(&mut self) -> Result<(), SecureChatError> {
        self.connected_peers.clear();
        Ok(())
    }
}

/// Transport registry managing all active transports
pub struct TransportRegistry {
    transports: Vec<Box<dyn Transport>>,
}

impl TransportRegistry {
    pub fn new() -> Self {
        Self { transports: Vec::new() }
    }
    
    pub fn register(&mut self, transport: Box<dyn Transport>) {
        self.transports.push(transport);
    }
    
    pub fn get(&self, id: &str) -> Option<&dyn Transport> {
        self.transports.iter().find(|t| t.id() == id).map(|t| t.as_ref())
    }
    
    pub fn get_mut(&mut self, id: &str) -> Option<&mut dyn Transport> {
        self.transports.iter_mut().find(|t| t.id() == id).map(|t| t.as_mut())
    }
    
    pub fn iter(&self) -> impl Iterator<Item = &dyn Transport> {
        self.transports.iter().map(|t| t.as_ref())
    }
}
