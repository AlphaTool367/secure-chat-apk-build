//! Peer discovery mechanisms
//! 
//! # Modes
//! - BLE beacon advertisement (encrypted payload)
//! - mDNS/Bonjour for WiFi Direct
//! - DHT announcements for libp2p
//! - Manual exchange (QR code, NFC bump)

use crate::SecureChatError;
use serde::{Serialize, Deserialize};
use std::collections::HashMap;

/// Discovery advertisement
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiscoveryAdvertisement {
    pub anon_id: String,
    pub verifying_key_fingerprint: String,
    pub x25519_public: Vec<u8>,
    pub timestamp: u64,
    pub supported_modes: Vec<super::NetworkMode>,
    pub nonce: Vec<u8>, // Prevents replay
}

/// Peer discovery result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiscoveredPeer {
    pub anon_id: String,
    pub fingerprint: String,
    pub x25519_public: Vec<u8>,
    pub last_seen: u64,
    pub transport_id: String,
    pub metadata: HashMap<String, String>,
}

/// Discovery manager
pub struct DiscoveryManager {
    known_peers: HashMap<String, DiscoveredPeer>,
    trust_cache: super::super::crypto::keys::PeerKeyCache,
}

impl DiscoveryManager {
    pub fn new() -> Self {
        Self {
            known_peers: HashMap::new(),
            trust_cache: super::super::crypto::keys::PeerKeyCache::new(),
        }
    }
    
    /// Process an incoming advertisement
    pub fn on_advertisement(&mut self, ad: DiscoveryAdvertisement) -> Result<DiscoveredPeer, SecureChatError> {
        let fingerprint = super::super::crypto::keys::generate_fingerprint(&ad.x25519_public);
        
        let peer = DiscoveredPeer {
            anon_id: ad.anon_id.clone(),
            fingerprint: fingerprint.clone(),
            x25519_public: ad.x25519_public,
            last_seen: ad.timestamp,
            transport_id: "unknown".to_string(),
            metadata: HashMap::new(),
        };
        
        self.known_peers.insert(ad.anon_id.clone(), peer.clone());
        Ok(peer)
    }
    
    pub fn get_peer(&self, anon_id: &str) -> Option<&DiscoveredPeer> {
        self.known_peers.get(anon_id)
    }
    
    pub fn list_peers(&self) -> Vec<&DiscoveredPeer> {
        self.known_peers.values().collect()
    }
}
