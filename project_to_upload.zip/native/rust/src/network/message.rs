//! Message wire format and routing
//! 
//! # Format
//! | Field | Size | Description |
//! |-------|------|-------------|
//! | Magic | 4 | 'SCM1' |
//! | Version | 1 | Protocol version |
//! | Flags | 1 | Encryption type, compression |
//! | Payload len | 4 | Encrypted payload size |
//! | Payload | N | Encrypted message data |
//! | MAC | 16 | Poly1305 tag |

use crate::SecureChatError;
use serde::{Serialize, Deserialize};

/// Wire message header
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WireHeader {
    pub magic: [u8; 4],
    pub version: u8,
    pub flags: u8,
    pub payload_length: u32,
}

impl WireHeader {
    pub const MAGIC: [u8; 4] = *b"SCM1";
    pub const VERSION: u8 = 1;
    
    pub fn new(payload_length: u32, flags: u8) -> Self {
        Self {
            magic: Self::MAGIC,
            version: Self::VERSION,
            flags,
            payload_length,
        }
    }
    
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut result = Vec::with_capacity(10);
        result.extend_from_slice(&self.magic);
        result.push(self.version);
        result.push(self.flags);
        result.extend_from_slice(&self.payload_length.to_be_bytes());
        result
    }
    
    pub fn from_bytes(data: &[u8]) -> Result<Self, SecureChatError> {
        if data.len() < 10 {
            return Err(SecureChatError::InvalidInput("Header too short".into()));
        }
        
        let mut magic = [0u8; 4];
        magic.copy_from_slice(&data[0..4]);
        if magic != Self::MAGIC {
            return Err(SecureChatError::Protocol("Invalid magic bytes".into()));
        }
        
        let version = data[4];
        if version != Self::VERSION {
            return Err(SecureChatError::Protocol(format!("Unsupported version: {}", version)));
        }
        
        let flags = data[5];
        let mut payload_len = [0u8; 4];
        payload_len.copy_from_slice(&data[6..10]);
        let payload_length = u32::from_be_bytes(payload_len);
        
        Ok(Self {
            magic,
            version,
            flags,
            payload_length,
        })
    }
}

/// Complete wire message
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WireMessage {
    pub header: WireHeader,
    pub payload: Vec<u8>, // Encrypted
    pub mac: [u8; 16],
}

/// Message types
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum MessageType {
    HandshakeInit = 0x01,
    HandshakeResponse = 0x02,
    Data = 0x10,
    DataChunk = 0x11,
    Ack = 0x20,
    Presence = 0x30,
    MeshRelay = 0x40,
}

/// Payload envelope (before encryption)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Payload {
    pub message_type: MessageType,
    pub sender_id: String,
    pub timestamp: u64,
    pub nonce: Vec<u8>,
    pub data: Vec<u8>,
}

/// Chunked message handling for large files
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChunkedMessage {
    pub message_id: String,
    pub chunk_index: u32,
    pub total_chunks: u32,
    pub chunk_data: Vec<u8>,
}

/// Build a wire message from encrypted payload
pub fn build_wire_message(encrypted_payload: &[u8], flags: u8) -> Result<Vec<u8>, SecureChatError> {
    let header = WireHeader::new(encrypted_payload.len() as u32, flags);
    let mut result = header.to_bytes();
    result.extend_from_slice(encrypted_payload);
    Ok(result)
}

/// Parse a wire message from bytes
pub fn parse_wire_message(data: &[u8]) -> Result<WireMessage, SecureChatError> {
    let header = WireHeader::from_bytes(data)?;
    let payload_start = 10;
    let payload_end = payload_start + header.payload_length as usize;
    
    if data.len() < payload_end {
        return Err(SecureChatError::InvalidInput("Incomplete message".into()));
    }
    
    let payload = data[payload_start..payload_end].to_vec();
    let mut mac = [0u8; 16];
    if data.len() >= payload_end + 16 {
        mac.copy_from_slice(&data[payload_end..payload_end + 16]);
    }
    
    Ok(WireMessage {
        header,
        payload,
        mac,
    })
}
