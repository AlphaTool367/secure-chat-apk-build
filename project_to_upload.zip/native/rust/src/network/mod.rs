//! Network module - P2P transport abstractions
//! 
//! # Transport Modes
//! - BLE: Bluetooth Low Energy for nearby offline chat
//! - WiFi Direct: Local network without internet
//! - libp2p: Online P2P with DHT routing (optional feature)
//! - Tor/I2P: Plugin-based privacy routing

pub mod transport;
pub mod message;
pub mod discovery;

use crate::SecureChatError;
use serde::{Serialize, Deserialize};

/// Network mode priority (tries in order)
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum NetworkMode {
    BleDirect = 0,      // BLE 5.0 direct
    WifiDirect = 1,     // Wi-Fi Direct / Local hotspot
    LocalMesh = 2,      // Multi-hop relay via trusted peers
    Libp2p = 3,         // Online DHT routing
    TorProxy = 4,       // Tor/I2P plugin
}

/// Connection state for a peer
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum ConnectionState {
    Disconnected,
    Discovering,
    Connecting,
    Connected,
    Authenticated, // Handshake complete
}

/// Network statistics (for diagnostics, no telemetry sent)
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct NetworkStats {
    pub bytes_sent: u64,
    pub bytes_received: u64,
    pub messages_sent: u32,
    pub messages_received: u32,
    pub connection_time_ms: u64,
    pub failed_connections: u32,
}
