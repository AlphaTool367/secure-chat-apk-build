//! Plugin architecture - isolated feature modules
//! 
//! # Design
//! - Plugins run in isolates (Dart) or separate threads (Rust)
//! - Manifest-based permission system
//! - Cryptographic signature verification before loading
//! - Sandboxed access to core APIs

use crate::SecureChatError;
use serde::{Serialize, Deserialize};

/// Plugin interface that all plugins must implement
pub trait Plugin: Send + Sync {
    fn id(&self) -> &str;
    fn version(&self) -> &str;
    fn permissions(&self) -> &[PluginPermission];
    fn init(&mut self) -> Result<(), SecureChatError>;
    fn on_message(&mut self, sender_id: &str, data: &[u8]) -> Result<(), SecureChatError>;
    fn on_network_change(&mut self, mode: super::network::NetworkMode) -> Result<(), SecureChatError>;
    fn shutdown(&mut self) -> Result<(), SecureChatError>;
}

/// Plugin permission types
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum PluginPermission {
    NetworkProxy = 0x01,
    MeshRelay = 0x02,
    TorRouting = 0x04,
    CustomCrypto = 0x08,
    StorageAccess = 0x10,
    CameraAccess = 0x20,
    LocationAccess = 0x40,
}

/// Plugin manifest (parsed from .plugin package)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginManifest {
    pub id: String,
    pub name: String,
    pub version: String,
    pub author: String,
    pub signature: Vec<u8>,
    pub permissions: Vec<PluginPermission>,
    pub min_app_version: String,
    pub entry_point: String,
}

/// Plugin registry
pub struct PluginRegistry {
    plugins: Vec<Box<dyn Plugin>>,
    manifests: Vec<PluginManifest>,
}

impl PluginRegistry {
    pub fn new() -> Self {
        Self {
            plugins: Vec::new(),
            manifests: Vec::new(),
        }
    }
    
    pub fn load(&mut self, manifest: PluginManifest, plugin: Box<dyn Plugin>) -> Result<(), SecureChatError> {
        // Verify signature
        self.verify_signature(&manifest)?;
        
        // Check permissions
        self.validate_permissions(&manifest)?;
        
        // Initialize
        let mut plugin = plugin;
        plugin.init()?;
        
        self.plugins.push(plugin);
        self.manifests.push(manifest);
        Ok(())
    }
    
    pub fn get(&self, id: &str) -> Option<&dyn Plugin> {
        self.plugins.iter().find(|p| p.id() == id).map(|p| p.as_ref())
    }
    
    pub fn get_mut(&mut self, id: &str) -> Option<&mut dyn Plugin> {
        self.plugins.iter_mut().find(|p| p.id() == id).map(|p| p.as_mut())
    }
    
    pub fn unload(&mut self, id: &str) -> Result<(), SecureChatError> {
        if let Some(idx) = self.plugins.iter().position(|p| p.id() == id) {
            self.plugins.remove(idx);
            self.manifests.remove(idx);
        }
        Ok(())
    }
    
    fn verify_signature(&self, _manifest: &PluginManifest) -> Result<(), SecureChatError> {
        // Real impl: verify Ed25519 signature against built-in public key
        Ok(())
    }
    
    fn validate_permissions(&self, _manifest: &PluginManifest) -> Result<(), SecureChatError> {
        // Check against user-approved permissions
        Ok(())
    }
}

/// Example TorQ plugin
pub struct TorQPlugin {
    pub id: String,
    pub proxy_port: u16,
}

impl TorQPlugin {
    pub fn new() -> Self {
        Self {
            id: "torq_v1".to_string(),
            proxy_port: 9050,
        }
    }
}

impl Plugin for TorQPlugin {
    fn id(&self) -> &str { &self.id }
    fn version(&self) -> &str { "1.0.0" }
    fn permissions(&self) -> &[PluginPermission] {
        &[PluginPermission::TorRouting, PluginPermission::NetworkProxy]
    }
    fn init(&mut self) -> Result<(), SecureChatError> {
        // Start tor daemon
        Ok(())
    }
    fn on_message(&mut self, _sender_id: &str, _data: &[u8]) -> Result<(), SecureChatError> {
        Ok(())
    }
    fn on_network_change(&mut self, _mode: super::network::NetworkMode) -> Result<(), SecureChatError> {
        Ok(())
    }
    fn shutdown(&mut self) -> Result<(), SecureChatError> {
        Ok(())
    }
}
