//! Offline-First, Zero-DB, Zero-Signup, Fully Anonymous & Secure Chat Core
//! 
//! # Security Architecture
//! - Memory-safe Rust implementation with zeroization of all key material
//! - Signal Double Ratchet for forward secrecy
//! - X25519 ECDH for key exchange
//! - ChaCha20-Poly1305 for authenticated encryption
//! - Argon2id for key derivation
//! - No network telemetry, no crash reporting, no analytics
//!
//! # Cryptographic Primitives
//! | Purpose | Algorithm |
//! |---------|-----------|
//! | Identity | Ed25519 |
//! | Key Exchange | X25519 ECDH |
//! | Symmetric Encryption | ChaCha20-Poly1305 |
//! | Key Derivation | Argon2id |
//! | Hashing | BLAKE2b |
//! | Forward Secrecy | Signal Double Ratchet |

#![deny(unsafe_code)]
#![warn(missing_docs)]
#![warn(clippy::all, clippy::pedantic)]
#![allow(clippy::module_name_repetitions)]

use flutter_rust_bridge::frb;
use zeroize::Zeroize;

mod crypto;
mod network;
mod storage;
mod utils;
mod plugin;

pub use crypto::*;
pub use network::*;
pub use storage::*;
pub use utils::*;
pub use plugin::*;

use crate::crypto::identity::IdentityManager;
use crate::crypto::protocol::DoubleRatchet;
use crate::storage::secure_store::SecureStorage;

/// Global secure context - all sensitive operations flow through this
/// 
/// # Security
/// - All key material is zeroized on drop
/// - Mutex-protected access prevents race conditions
/// - No cloning of secrets - only references
#[derive(Zeroize)]
pub struct SecureContext {
    #[zeroize(skip)]
    pub identity: IdentityManager,
    #[zeroize(skip)]
    pub storage: SecureStorage,
    pub active_ratchets: Vec<DoubleRatchet>,
}

impl SecureContext {
    /// Initialize a new secure context with fresh identity
    /// 
    /// # Arguments
    /// * `app_dir` - Application data directory path (encrypted storage root)
    /// 
    /// # Errors
    /// Returns error if identity generation or storage initialization fails
    #[frb(sync)]
    pub fn init(app_dir: String) -> Result<Self, SecureChatError> {
        let storage = SecureStorage::new(&app_dir)?;
        let identity = IdentityManager::generate(&storage)?;
        
        Ok(Self {
            identity,
            storage,
            active_ratchets: Vec::new(),
        })
    }

    /// Restore from existing encrypted backup
    #[frb(sync)]
    pub fn restore_from_backup(
        app_dir: String,
        backup_data: Vec<u8>,
        password: String,
    ) -> Result<Self, SecureChatError> {
        let storage = SecureStorage::new(&app_dir)?;
        let identity = IdentityManager::restore_from_backup(&storage, &backup_data, &password)?;
        
        Ok(Self {
            identity,
            storage,
            active_ratchets: Vec::new(),
        })
    }

    /// Export encrypted identity backup (QR/USB compatible)
    #[frb(sync)]
    pub fn export_backup(&self, password: String) -> Result<Vec<u8>, SecureChatError> {
        self.identity.export_backup(&self.storage, &password)
    }
}

/// Core error types for all secure chat operations
#[derive(Debug, thiserror::Error)]
pub enum SecureChatError {
    #[error("Cryptographic operation failed: {0}")]
    Crypto(String),
    
    #[error("Storage operation failed: {0}")]
    Storage(String),
    
    #[error("Network operation failed: {0}")]
    Network(String),
    
    #[error("Identity operation failed: {0}")]
    Identity(String),
    
    #[error("Protocol violation: {0}")]
    Protocol(String),
    
    #[error("Invalid input: {0}")]
    InvalidInput(String),
    
    #[error("Permission denied: {0}")]
    PermissionDenied(String),
}

/// FFI bridge initialization
#[frb(init)]
pub fn init_app() {
    // Initialize libsodium (thread-safe, idempotent)
    let _ = sodiumoxide::init();
    
    // Set up minimal logging for debug builds only
    #[cfg(debug_assertions)]
    {
        env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("warn"))
            .format_timestamp(None)
            .init();
    }
}