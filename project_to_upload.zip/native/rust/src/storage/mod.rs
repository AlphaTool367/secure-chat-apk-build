//! Storage module - encrypted file-based storage with optional SQLite indexing
//! 
//! # Design
//! - No cloud sync, no remote database
//! - All files encrypted at rest with AES-256-GCM
//! - Master key derived from OS secure enclave (Android Keystore / iOS Keychain)
//! - SQLite only used for local indexing (encrypted with SQLCipher concept)

pub mod secure_store;
pub mod chat_store;
pub mod media_store;

use crate::SecureChatError;
use std::path::{Path, PathBuf};
use std::fs;
use std::io::Write;

/// Base storage manager for all encrypted files
pub struct StorageManager {
    pub app_dir: PathBuf,
    pub master_key: [u8; 32],
}

impl StorageManager {
    pub fn new(app_dir: &str, master_key: [u8; 32]) -> Result<Self, SecureChatError> {
        let path = PathBuf::from(app_dir);
        Self::ensure_dirs(&path)?;
        Ok(Self {
            app_dir: path,
            master_key,
        })
    }
    
    fn ensure_dirs(base: &Path) -> Result<(), SecureChatError> {
        let dirs = &[
            "identity",
            "identity/peer_keys",
            "chats",
            "media/cache",
            "media/vault",
            "plugins",
            "config",
        ];
        for dir in dirs {
            let path = base.join(dir);
            fs::create_dir_all(&path)
                .map_err(|e| SecureChatError::Storage(format!("Failed to create dir: {}", e)))?;
        }
        Ok(())
    }
    
    pub fn write_file(&self, relative_path: &str, data: &[u8]) -> Result<(), SecureChatError> {
        let path = self.app_dir.join(relative_path);
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)
                .map_err(|e| SecureChatError::Storage(format!("Failed to create parent: {}", e)))?;
        }
        let mut file = fs::File::create(&path)
            .map_err(|e| SecureChatError::Storage(format!("Failed to create file: {}", e)))?;
        file.write_all(data)
            .map_err(|e| SecureChatError::Storage(format!("Failed to write file: {}", e)))?;
        file.sync_all()
            .map_err(|e| SecureChatError::Storage(format!("Failed to sync file: {}", e)))?;
        Ok(())
    }
    
    pub fn read_file(&self, relative_path: &str) -> Result<Vec<u8>, SecureChatError> {
        let path = self.app_dir.join(relative_path);
        fs::read(&path)
            .map_err(|e| SecureChatError::Storage(format!("Failed to read file: {}", e)))
    }
    
    pub fn file_exists(&self, relative_path: &str) -> bool {
        self.app_dir.join(relative_path).exists()
    }
    
    pub fn delete_file(&self, relative_path: &str) -> Result<(), SecureChatError> {
        let path = self.app_dir.join(relative_path);
        if path.exists() {
            fs::remove_file(&path)
                .map_err(|e| SecureChatError::Storage(format!("Failed to delete file: {}", e)))?;
        }
        Ok(())
    }
    
    pub fn list_files(&self, relative_dir: &str) -> Result<Vec<String>, SecureChatError> {
        let path = self.app_dir.join(relative_dir);
        let mut files = Vec::new();
        if path.is_dir() {
            for entry in fs::read_dir(&path)
                .map_err(|e| SecureChatError::Storage(format!("Failed to read dir: {}", e)))? {
                let entry = entry
                    .map_err(|e| SecureChatError::Storage(format!("Dir entry error: {}", e)))?;
                if let Some(name) = entry.file_name().to_str() {
                    files.push(name.to_string());
                }
            }
        }
        Ok(files)
    }
}
