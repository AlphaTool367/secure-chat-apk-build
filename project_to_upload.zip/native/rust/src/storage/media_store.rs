//! Media storage - encrypted attachments with auto-wipe cache
//! 
//! # Security
//! - Originals stored in vault/ encrypted with AES-256-GCM
//! - Decrypted cache/ auto-wiped after viewing or on app background
//! - Chunked encryption for files > 500KB
//! - Hash verification before decryption

use crate::SecureChatError;
use crate::crypto::cipher::{hash_blake2b, encrypt_aes_gcm, decrypt_aes_gcm};
use serde::{Serialize, Deserialize};
use std::path::{Path, PathBuf};
use std::io::Write;

/// Encrypted media entry
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MediaEntry {
    pub id: String,
    pub original_hash: [u8; 32],
    pub encrypted_path: String,
    pub encryption_key: [u8; 32],
    pub file_size: u64,
    pub mime_type: String,
    pub created_at: u64,
    pub chunks: Vec<ChunkInfo>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChunkInfo {
    pub index: u32,
    pub size: u32,
    pub hash: [u8; 32],
}

/// Media vault manager
pub struct MediaStore {
    pub vault_dir: PathBuf,
    pub cache_dir: PathBuf,
    pub max_cache_size: u64, // bytes
}

impl MediaStore {
    pub fn new(base_dir: &Path) -> Result<Self, SecureChatError> {
        let vault_dir = base_dir.join("media/vault");
        let cache_dir = base_dir.join("media/cache");
        
        std::fs::create_dir_all(&vault_dir)
            .map_err(|e| SecureChatError::Storage(format!("Failed to create vault: {}", e)))?;
        std::fs::create_dir_all(&cache_dir)
            .map_err(|e| SecureChatError::Storage(format!("Failed to create cache: {}", e)))?;
        
        Ok(Self {
            vault_dir,
            cache_dir,
            max_cache_size: 100 * 1024 * 1024, // 100MB cache limit
        })
    }
    
    /// Store a file in the vault (encrypts and deletes original)
    pub fn store_file(
        &self,
        source_path: &Path,
        media_id: &str,
        mime_type: &str,
    ) -> Result<MediaEntry, SecureChatError> {
        let data = std::fs::read(source_path)
            .map_err(|e| SecureChatError::Storage(format!("Failed to read source: {}", e)))?;
        
        let original_hash = hash_blake2b(&data);
        let encryption_key = crate::crypto::cipher::secure_random(32);
        let mut key_array = [0u8; 32];
        key_array.copy_from_slice(&encryption_key);
        
        let file_size = data.len() as u64;
        
        // Chunk if > 500KB
        let chunks = if data.len() > 500 * 1024 {
            self.store_chunked(&data, media_id, &key_array, &original_hash)?
        } else {
            let encrypted = encrypt_aes_gcm(&data, &key_array)?;
            let vault_path = self.vault_dir.join(format!("{}.enc", media_id));
            std::fs::write(&vault_path, &encrypted)
                .map_err(|e| SecureChatError::Storage(format!("Failed to write vault: {}", e)))?;
            vec![ChunkInfo {
                index: 0,
                size: encrypted.len() as u32,
                hash: hash_blake2b(&encrypted),
            }]
        };
        
        // Secure delete source (overwrite with zeros)
        self.secure_delete(source_path)?;
        
        Ok(MediaEntry {
            id: media_id.to_string(),
            original_hash,
            encrypted_path: format!("media/vault/{}.enc", media_id),
            encryption_key: key_array,
            file_size,
            mime_type: mime_type.to_string(),
            created_at: current_timestamp(),
            chunks,
        })
    }
    
    fn store_chunked(
        &self,
        data: &[u8],
        media_id: &str,
        key: &[u8; 32],
        original_hash: &[u8; 32],
    ) -> Result<Vec<ChunkInfo>, SecureChatError> {
        let chunk_size = 256 * 1024; // 256KB chunks
        let mut chunks = Vec::new();
        
        for (i, chunk) in data.chunks(chunk_size).enumerate() {
            let encrypted = encrypt_aes_gcm(chunk, key)?;
            let chunk_path = self.vault_dir.join(format!("{}_{}.enc", media_id, i));
            std::fs::write(&chunk_path, &encrypted)
                .map_err(|e| SecureChatError::Storage(format!("Chunk write failed: {}", e)))?;
            
            chunks.push(ChunkInfo {
                index: i as u32,
                size: encrypted.len() as u32,
                hash: hash_blake2b(&encrypted),
            });
        }
        
        Ok(chunks)
    }
    
    /// Decrypt to cache for viewing (caller must call wipe_cache after)
    pub fn decrypt_to_cache(&self, entry: &MediaEntry) -> Result<PathBuf, SecureChatError> {
        let cache_path = self.cache_dir.join(&entry.id);
        
        if entry.chunks.len() == 1 {
            let vault_path = self.vault_dir.join(format!("{}.enc", entry.id));
            let encrypted = std::fs::read(&vault_path)
                .map_err(|e| SecureChatError::Storage(format!("Failed to read vault: {}", e)))?;
            let decrypted = decrypt_aes_gcm(&encrypted, &entry.encryption_key)?;
            
            // Verify hash
            let hash = hash_blake2b(&decrypted);
            if hash != entry.original_hash {
                return Err(SecureChatError::Crypto("Media hash mismatch - possible tampering".into()));
            }
            
            std::fs::write(&cache_path, &decrypted)
                .map_err(|e| SecureChatError::Storage(format!("Cache write failed: {}", e)))?;
        } else {
            let mut decrypted = Vec::new();
            for chunk in &entry.chunks {
                let chunk_path = self.vault_dir.join(format!("{}_{}.enc", entry.id, chunk.index));
                let encrypted = std::fs::read(&chunk_path)
                    .map_err(|e| SecureChatError::Storage(format!("Chunk read failed: {}", e)))?;
                let chunk_data = decrypt_aes_gcm(&encrypted, &entry.encryption_key)?;
                decrypted.extend_from_slice(&chunk_data);
            }
            
            let hash = hash_blake2b(&decrypted);
            if hash != entry.original_hash {
                return Err(SecureChatError::Crypto("Chunked media hash mismatch".into()));
            }
            
            std::fs::write(&cache_path, &decrypted)
                .map_err(|e| SecureChatError::Storage(format!("Cache write failed: {}", e)))?;
        }
        
        Ok(cache_path)
    }
    
    /// Wipe all decrypted cache files
    pub fn wipe_cache(&self) -> Result<(), SecureChatError> {
        if !self.cache_dir.exists() {
            return Ok(());
        }
        
        for entry in std::fs::read_dir(&self.cache_dir)
            .map_err(|e| SecureChatError::Storage(format!("Cache read failed: {}", e)))? {
            let entry = entry
                .map_err(|e| SecureChatError::Storage(format!("Cache entry error: {}", e)))?;
            let path = entry.path();
            if path.is_file() {
                self.secure_delete(&path)?;
            }
        }
        
        Ok(())
    }
    
    /// Secure file deletion (overwrite then remove)
    fn secure_delete(&self, path: &Path) -> Result<(), SecureChatError> {
        if !path.exists() {
            return Ok(());
        }
        
        let size = std::fs::metadata(path)
            .map_err(|e| SecureChatError::Storage(format!("Metadata failed: {}", e)))?
            .len() as usize;
        
        // Overwrite with zeros (3 passes for sensitive data)
        for _ in 0..3 {
            let zeros = vec![0u8; size];
            let mut file = std::fs::OpenOptions::new()
                .write(true)
                .open(path)
                .map_err(|e| SecureChatError::Storage(format!("Open for overwrite failed: {}", e)))?;
            file.write_all(&zeros)
                .map_err(|e| SecureChatError::Storage(format!("Overwrite failed: {}", e)))?;
            file.sync_all()
                .map_err(|e| SecureChatError::Storage(format!("Sync failed: {}", e)))?;
            drop(file);
        }
        
        std::fs::remove_file(path)
            .map_err(|e| SecureChatError::Storage(format!("Remove failed: {}", e)))?;
        
        Ok(())
    }
}

fn current_timestamp() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}
