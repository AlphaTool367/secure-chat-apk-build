//! Chat storage - per-peer encrypted message storage using SQLite
//! 
//! # Design
//! - Each peer has their own SQLite database (compartmentalization)
//! - Database file encrypted with AES-256-GCM using per-peer key
//! - Messages stored with only timestamp and encrypted payload
//! - Attachments stored as encrypted blobs in filesystem

use crate::SecureChatError;
use crate::storage::StorageManager;
use crate::crypto::cipher::{encrypt_aes_gcm, decrypt_aes_gcm};
use serde::{Serialize, Deserialize};
use zeroize::Zeroize;

/// Per-peer chat database handle
pub struct ChatStore {
    pub peer_id: String,
    pub db_path: String,
    pub encryption_key: [u8; 32],
}

/// Message record stored in database
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MessageRecord {
    pub id: String,
    pub timestamp: u64,
    pub sender_id: String,
    pub direction: MessageDirection,
    pub encrypted_payload: Vec<u8>,
    pub message_type: MessageType,
    pub read: bool,
    pub delivered: bool,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum MessageDirection {
    Incoming,
    Outgoing,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum MessageType {
    Text,
    Image,
    Video,
    Document,
    Audio,
    Location,
}

/// Chat index entry (stored in main index.json)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatIndexEntry {
    pub peer_id: String,
    pub peer_anon_id: String,
    pub last_message_hash: String,
    pub last_message_time: u64,
    pub unread_count: u32,
    pub message_count: u64,
    pub verified: bool,
}

impl ChatStore {
    /// Open or create chat store for a peer
    pub fn open(
        storage: &StorageManager,
        peer_id: &str,
        encryption_key: [u8; 32],
    ) -> Result<Self, SecureChatError> {
        let db_path = format!("chats/{}/messages.db", sanitize(peer_id));
        let path = storage.app_dir.join(&db_path);
        
        // Ensure directory exists
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| SecureChatError::Storage(format!("Failed to create chat dir: {}", e)))?;
        }
        
        // Initialize encrypted SQLite database
        Self::init_database(&path, &encryption_key)?;
        
        Ok(Self {
            peer_id: peer_id.to_string(),
            db_path,
            encryption_key,
        })
    }
    
    fn init_database(path: &std::path::Path, key: &[u8; 32]) -> Result<(), SecureChatError> {
        use rusqlite::{Connection, params};
        
        let conn = Connection::open(path)
            .map_err(|e| SecureChatError::Storage(format!("Failed to open DB: {}", e)))?;
        
        // Configure encryption (SQLCipher concept - pragma key)
        // In production, use sqlcipher or similar encrypted SQLite
        let _key_hex = hex::encode(key);
        
        conn.execute_batch(r#"
            PRAGMA journal_mode = WAL;
            PRAGMA foreign_keys = ON;
            
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                timestamp INTEGER NOT NULL,
                sender_id TEXT NOT NULL,
                direction INTEGER NOT NULL,
                encrypted_payload BLOB NOT NULL,
                message_type INTEGER NOT NULL,
                read INTEGER NOT NULL DEFAULT 0,
                delivered INTEGER NOT NULL DEFAULT 0
            );
            
            CREATE INDEX IF NOT EXISTS idx_messages_time 
                ON messages(timestamp);
            
            CREATE TABLE IF NOT EXISTS attachments (
                id TEXT PRIMARY KEY,
                message_id TEXT NOT NULL,
                filename TEXT,
                file_size INTEGER,
                encrypted_path TEXT,
                encryption_iv TEXT,
                FOREIGN KEY (message_id) REFERENCES messages(id)
            );
        "#).map_err(|e| SecureChatError::Storage(format!("Failed to init schema: {}", e)))?;
        
        conn.close()
            .map_err(|(_, e)| SecureChatError::Storage(format!("Failed to close DB: {}", e)))?;
        
        Ok(())
    }
    
    pub fn insert_message(&self, msg: &MessageRecord) -> Result<(), SecureChatError> {
        use rusqlite::{Connection, params};
        
        let path = self.storage_path();
        let conn = Connection::open(&path)
            .map_err(|e| SecureChatError::Storage(format!("DB open failed: {}", e)))?;
        
        conn.execute(
            "INSERT INTO messages (id, timestamp, sender_id, direction, encrypted_payload, message_type, read, delivered)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
            params![
                msg.id,
                msg.timestamp as i64,
                msg.sender_id,
                msg.direction as i32,
                msg.encrypted_payload,
                msg.message_type as i32,
                msg.read as i32,
                msg.delivered as i32,
            ],
        ).map_err(|e| SecureChatError::Storage(format!("Insert failed: {}", e)))?;
        
        conn.close()
            .map_err(|(_, e)| SecureChatError::Storage(format!("DB close failed: {}", e)))?;
        
        Ok(())
    }
    
    pub fn get_messages(&self, limit: usize, offset: usize) -> Result<Vec<MessageRecord>, SecureChatError> {
        use rusqlite::{Connection, params};
        
        let path = self.storage_path();
        let conn = Connection::open(&path)
            .map_err(|e| SecureChatError::Storage(format!("DB open failed: {}", e)))?;
        
        let mut stmt = conn.prepare(
            "SELECT id, timestamp, sender_id, direction, encrypted_payload, message_type, read, delivered
             FROM messages
             ORDER BY timestamp DESC
             LIMIT ?1 OFFSET ?2"
        ).map_err(|e| SecureChatError::Storage(format!("Prepare failed: {}", e)))?;
        
        let messages = stmt.query_map(params![limit as i64, offset as i64], |row| {
            Ok(MessageRecord {
                id: row.get(0)?,
                timestamp: row.get::<_, i64>(1)? as u64,
                sender_id: row.get(2)?,
                direction: match row.get::<_, i32>(3)? {
                    0 => MessageDirection::Incoming,
                    _ => MessageDirection::Outgoing,
                },
                encrypted_payload: row.get(4)?,
                message_type: match row.get::<_, i32>(5)? {
                    0 => MessageType::Text,
                    1 => MessageType::Image,
                    2 => MessageType::Video,
                    3 => MessageType::Document,
                    4 => MessageType::Audio,
                    _ => MessageType::Text,
                },
                read: row.get::<_, i32>(6)? != 0,
                delivered: row.get::<_, i32>(7)? != 0,
            })
        }).map_err(|e| SecureChatError::Storage(format!("Query failed: {}", e)))?;
        
        let mut result = Vec::new();
        for msg in messages {
            result.push(msg.map_err(|e| SecureChatError::Storage(format!("Row parse failed: {}", e)))?);
        }
        
        conn.close()
            .map_err(|(_, e)| SecureChatError::Storage(format!("DB close failed: {}", e)))?;
        
        Ok(result)
    }
    
    pub fn mark_read(&self, message_ids: &[String]) -> Result<(), SecureChatError> {
        use rusqlite::Connection;
        
        let path = self.storage_path();
        let conn = Connection::open(&path)
            .map_err(|e| SecureChatError::Storage(format!("DB open failed: {}", e)))?;
        
        let placeholders = message_ids.iter().map(|_| "?").collect::<Vec<_>>().join(",");
        let sql = format!("UPDATE messages SET read = 1 WHERE id IN ({})" , placeholders);
        
        let mut stmt = conn.prepare(&sql)
            .map_err(|e| SecureChatError::Storage(format!("Prepare failed: {}", e)))?;
        
        for (i, id) in message_ids.iter().enumerate() {
            stmt.raw_bind_parameter(i + 1, id)
                .map_err(|e| SecureChatError::Storage(format!("Bind failed: {}", e)))?;
        }
        
        stmt.raw_execute()
            .map_err(|e| SecureChatError::Storage(format!("Execute failed: {}", e)))?;
        
        conn.close()
            .map_err(|(_, e)| SecureChatError::Storage(format!("DB close failed: {}", e)))?;
        
        Ok(())
    }
    
    fn storage_path(&self) -> std::path::PathBuf {
        std::path::PathBuf::from(&self.db_path)
    }
}

fn sanitize(name: &str) -> String {
    name.replace(|c: char| !c.is_alphanumeric(), "_")
}