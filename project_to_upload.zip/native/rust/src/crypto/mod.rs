//! Cryptographic module - Identity, Key Exchange, Encryption, Double Ratchet
//! 
//! # Memory Safety
//! - All key material uses `Zeroize` for secure cleanup
//! - `Secret` wrapper prevents accidental exposure in logs
//! - Constant-time operations where available
//! 
//! # Algorithms
//! - Ed25519: Digital signatures for identity
//! - X25519: ECDH key exchange
//! - ChaCha20-Poly1305: Authenticated encryption
//! - Argon2id: Password-based key derivation
//! - BLAKE2b: Hashing

pub mod identity;
pub mod protocol;
pub mod cipher;
pub mod keys;

use zeroize::Zeroize;
use std::fmt;

/// Wrapper to prevent secrets from appearing in logs or debug output
#[derive(Clone, Zeroize)]
pub struct Secret<T: Zeroize>(T);

impl<T: Zeroize> Secret<T> {
    pub fn new(inner: T) -> Self {
        Self(inner)
    }
    
    pub fn expose(&self) -> &T {
        &self.0
    }
    
    pub fn into_inner(self) -> T {
        self.0
    }
}

impl<T: Zeroize> fmt::Debug for Secret<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "***REDACTED***")
    }
}

impl<T: Zeroize> fmt::Display for Secret<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "***REDACTED***")
    }
}

/// Verify a constant-time equality check for MACs/signatures
pub fn secure_compare(a: &[u8], b: &[u8]) -> bool {
    use subtle::ConstantTimeEq;
    a.ct_eq(b).into()
}
