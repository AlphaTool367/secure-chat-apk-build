//! Low-level cipher operations and utilities
//! 
//! Provides wrappers around ChaCha20-Poly1305 and AES-256-GCM
//! for different use cases (messages vs file encryption)

use crate::SecureChatError;
use chacha20poly1305::{ChaCha20Poly1305, Key, Nonce};
use chacha20poly1305::aead::{Aead, AeadCore};
use aes_gcm::{Aes256Gcm, aead::Aead as AesAead};
use aes_gcm::aead::generic_array::GenericArray;
use rand::rngs::OsRng;
use zeroize::Zeroize;

/// Encrypt a message using ChaCha20-Poly1305 (default for messages)
pub fn encrypt_chacha20(plaintext: &[u8], key: &[u8; 32]) -> Result<Vec<u8>, SecureChatError> {
    let cipher = ChaCha20Poly1305::new(Key::from_slice(key));
    let nonce = ChaCha20Poly1305::generate_nonce(&mut OsRng);
    let ciphertext = cipher.encrypt(&nonce, plaintext)
        .map_err(|e| SecureChatError::Crypto(format!("ChaCha20 encryption failed: {}", e)))?;
    
    let mut result = Vec::with_capacity(nonce.len() + ciphertext.len());
    result.extend_from_slice(&nonce);
    result.extend_from_slice(&ciphertext);
    Ok(result)
}

/// Decrypt a message using ChaCha20-Poly1305
pub fn decrypt_chacha20(ciphertext: &[u8], key: &[u8; 32]) -> Result<Vec<u8>, SecureChatError> {
    if ciphertext.len() < 12 {
        return Err(SecureChatError::InvalidInput("Ciphertext too short".into()));
    }
    
    let nonce = Nonce::from_slice(&ciphertext[..12]);
    let encrypted = &ciphertext[12..];
    
    let cipher = ChaCha20Poly1305::new(Key::from_slice(key));
    let plaintext = cipher.decrypt(nonce, encrypted)
        .map_err(|_| SecureChatError::Crypto("ChaCha20 decryption failed".into()))?;
    
    Ok(plaintext)
}

/// Encrypt a file/blob using AES-256-GCM (optimized for larger data)
pub fn encrypt_aes_gcm(plaintext: &[u8], key: &[u8; 32]) -> Result<Vec<u8>, SecureChatError> {
    let cipher = Aes256Gcm::new(GenericArray::from_slice(key));
    let nonce = GenericArray::from_slice(&[0u8; 12]); // Deterministic for file encryption with unique keys
    let ciphertext = cipher.encrypt(nonce, plaintext)
        .map_err(|e| SecureChatError::Crypto(format!("AES-GCM encryption failed: {}", e)))?;
    
    Ok(ciphertext)
}

/// Decrypt a file/blob using AES-256-GCM
pub fn decrypt_aes_gcm(ciphertext: &[u8], key: &[u8; 32]) -> Result<Vec<u8>, SecureChatError> {
    let cipher = Aes256Gcm::new(GenericArray::from_slice(key));
    let nonce = GenericArray::from_slice(&[0u8; 12]);
    let plaintext = cipher.decrypt(nonce, ciphertext)
        .map_err(|_| SecureChatError::Crypto("AES-GCM decryption failed".into()))?;
    
    Ok(plaintext)
}

/// Derive a key from password using Argon2id
pub fn derive_key(password: &[u8], salt: &[u8], output: &mut [u8; 32]) -> Result<(), SecureChatError> {
    use argon2::{Argon2, Algorithm, Version, Params};
    
    let params = Params::new(65536, 3, 4, Some(32))
        .map_err(|e| SecureChatError::Crypto(format!("Argon2 params failed: {}", e)))?;
    let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, params);
    
    argon2.hash_password_into(password, salt, output)
        .map_err(|e| SecureChatError::Crypto(format!("Argon2id derivation failed: {}", e)))?;
    
    Ok(())
}

/// Secure random bytes
pub fn secure_random(len: usize) -> Vec<u8> {
    use rand::RngCore;
    let mut buf = vec![0u8; len];
    OsRng.fill_bytes(&mut buf);
    buf
}

/// Hash data with BLAKE2b-256
pub fn hash_blake2b(data: &[u8]) -> [u8; 32] {
    use blake2::{Blake2b512, Digest};
    let mut hasher = Blake2b512::new();
    hasher.update(data);
    let result = hasher.finalize();
    let mut out = [0u8; 32];
    out.copy_from_slice(&result[..32]);
    out
}

/// HMAC-SHA256
pub fn hmac_sha256(key: &[u8], data: &[u8]) -> [u8; 32] {
    use hmac::{Hmac, Mac};
    use sha2::Sha256;
    
    type HmacSha256 = Hmac<Sha256>;
    let mut mac = HmacSha256::new_from_slice(key)
        .expect("HMAC key length valid");
    mac.update(data);
    let result = mac.finalize();
    let bytes = result.into_bytes();
    let mut out = [0u8; 32];
    out.copy_from_slice(&bytes);
    out
}
