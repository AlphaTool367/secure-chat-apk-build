//! Signal Double Ratchet implementation for forward secrecy
//! 
//! # Protocol Overview
//! 1. Initial key exchange via X25519 ECDH
//! 2. Root key updated with each message via ECDH or KDF ratchet step
//! 3. Chain keys derive message keys via HKDF
//! 4. Each message key used exactly once (self-destructing)
//!
//! # Security Properties
//! - Forward secrecy: Past keys cannot be recovered
//! - Future secrecy: Compromise doesn't affect future messages
//! - Break-in recovery: Continuous healing via DH ratchet

use crate::SecureChatError;
use x25519_dalek::{PublicKey as X25519PublicKey, StaticSecret as X25519SecretKey, ReusableSecret};
use sha2::{Sha256, Digest};
use hkdf::Hkdf;
use chacha20poly1305::{ChaCha20Poly1305, Key, Nonce};
use chacha20poly1305::aead::{Aead, AeadCore};
use rand::rngs::OsRng;
use serde::{Serialize, Deserialize};
use zeroize::{Zeroize, ZeroizeOnDrop};
use std::collections::HashMap;
use std::convert::TryInto;

/// Double Ratchet state per peer conversation
#[derive(Debug, Clone, Serialize, Deserialize, Zeroize, ZeroizeOnDrop)]
pub struct DoubleRatchet {
    /// Peer identifier (anon_id)
    pub peer_id: String,
    /// Our current DH ratchet key pair (empty if we haven't sent initial)
    #[zeroize(skip)]
    pub our_ratchet_key: Option<Vec<u8>>,
    /// Their current DH public key
    pub their_ratchet_key: Option<Vec<u8>>,
    /// Root key from which chain keys derive
    pub root_key: Vec<u8>,
    /// Sending chain key
    pub sending_chain_key: Vec<u8>,
    /// Receiving chain key
    pub receiving_chain_key: Vec<u8>,
    /// Message number in sending chain
    pub sending_message_number: u32,
    /// Message number in receiving chain
    pub receiving_message_number: u32,
    /// Previous chain length (for out-of-order handling)
    pub previous_chain_length: u32,
    /// Skipped message keys (stored with index for out-of-order)
    #[zeroize(skip)]
    pub skipped_keys: HashMap<u64, Vec<u8>>,
    /// Ratchet step counter (key version)
    pub ratchet_step: u32,
    /// Last message timestamp
    pub last_message_time: u64,
}

impl DoubleRatchet {
    /// Initialize as Alice (sender of first message)
    /// 
    /// # Arguments
    /// * `peer_id` - Anonymous peer identifier
    /// * `shared_secret` - Result of initial X25519 ECDH (32 bytes)
    /// * `their_public_key` - Peer's X25519 public key
    pub fn init_alice(
        peer_id: String,
        shared_secret: &[u8],
        their_public_key: &[u8],
    ) -> Result<Self, SecureChatError> {
        let mut csprng = OsRng;
        let our_secret = X25519SecretKey::random_from_rng(&mut csprng);
        let our_public = X25519PublicKey::from(&our_secret);
        
        let root_key = kdf_rk(shared_secret, &our_secret, &X25519PublicKey::from(
            their_public_key.try_into()
                .map_err(|_| SecureChatError::Protocol("Invalid public key".into()))?
        ))?;
        
        let (sending_ck, _) = kdf_ck(&root_key, 0)?;
        
        Ok(Self {
            peer_id,
            our_ratchet_key: Some(our_secret.to_bytes().to_vec()),
            their_ratchet_key: Some(their_public_key.to_vec()),
            root_key,
            sending_chain_key: sending_ck,
            receiving_chain_key: vec![0u8; 32], // Will be set on first receive
            sending_message_number: 0,
            receiving_message_number: 0,
            previous_chain_length: 0,
            skipped_keys: HashMap::new(),
            ratchet_step: 0,
            last_message_time: current_timestamp(),
        })
    }
    
    /// Initialize as Bob (receiver of first message)
    pub fn init_bob(
        peer_id: String,
        shared_secret: &[u8],
        our_secret_key: &[u8],
    ) -> Result<Self, SecureChatError> {
        let our_secret = X25519SecretKey::from(
            our_secret_key.try_into()
                .map_err(|_| SecureChatError::Protocol("Invalid secret key".into()))?
        );
        
        let root_key = kdf_rk_bob(shared_secret, &our_secret)?;
        let (_, receiving_ck) = kdf_ck(&root_key, 0)?;
        
        Ok(Self {
            peer_id,
            our_ratchet_key: Some(our_secret.to_bytes().to_vec()),
            their_ratchet_key: None, // Will be set on first message receive
            root_key,
            sending_chain_key: vec![0u8; 32], // Will be set on first DH ratchet
            receiving_chain_key: receiving_ck,
            sending_message_number: 0,
            receiving_message_number: 0,
            previous_chain_length: 0,
            skipped_keys: HashMap::new(),
            ratchet_step: 0,
            last_message_time: current_timestamp(),
        })
    }
    
    /// Encrypt a message - advances sending chain
    pub fn encrypt(&mut self, plaintext: &[u8]) -> Result<EncryptedMessage, SecureChatError> {
        let mk = self.next_sending_key()?;
        let cipher = ChaCha20Poly1305::new(Key::from_slice(&mk));
        let nonce = ChaCha20Poly1305::generate_nonce(&mut OsRng);
        let ciphertext = cipher.encrypt(&nonce, plaintext)
            .map_err(|e| SecureChatError::Crypto(format!("Encryption failed: {}", e)))?;
        
        let header = MessageHeader {
            ratchet_key: self.our_ratchet_key.as_ref().map(|k| {
                let secret = X25519SecretKey::from(k.as_slice().try_into().unwrap());
                X25519PublicKey::from(&secret).as_bytes().to_vec()
            }),
            message_number: self.sending_message_number,
            previous_chain_length: self.previous_chain_length,
        };
        
        self.sending_message_number += 1;
        self.last_message_time = current_timestamp();
        
        Ok(EncryptedMessage {
            header,
            nonce: nonce.to_vec(),
            ciphertext,
        })
    }
    
    /// Decrypt a message - handles DH ratchet and skipped keys
    pub fn decrypt(&mut self, msg: &EncryptedMessage) -> Result<Vec<u8>, SecureChatError> {
        // Check if we can decrypt with skipped keys
        let key_index = ((msg.header.previous_chain_length as u64) << 32) | (msg.header.message_number as u64);
        
        if let Some(skipped_mk) = self.skipped_keys.remove(&key_index) {
            let cipher = ChaCha20Poly1305::new(Key::from_slice(&skipped_mk));
            let nonce = Nonce::from_slice(&msg.nonce);
            return cipher.decrypt(nonce, msg.ciphertext.as_ref())
                .map_err(|_| SecureChatError::Crypto("Decryption with skipped key failed".into()));
        }
        
        // Check if DH ratchet happened (new ratchet key in header)
        if let Some(ref new_key) = msg.header.ratchet_key {
            if self.their_ratchet_key.as_ref() != Some(new_key) {
                // DH ratchet step - new chain
                self.dh_ratchet(new_key)?;
            }
        }
        
        // Advance receiving chain to match message number
        let target = msg.header.message_number;
        if target < self.receiving_message_number {
            return Err(SecureChatError::Protocol("Message too old - possible replay".into()));
        }
        
        // Store skipped keys
        while self.receiving_message_number < target {
            let skipped_mk = self.next_receiving_key()?;
            let idx = ((self.previous_chain_length as u64) << 32) | (self.receiving_message_number as u64);
            self.skipped_keys.insert(idx, skipped_mk);
            self.receiving_message_number += 1;
        }
        
        let mk = self.next_receiving_key()?;
        self.receiving_message_number += 1;
        
        let cipher = ChaCha20Poly1305::new(Key::from_slice(&mk));
        let nonce = Nonce::from_slice(&msg.nonce);
        let plaintext = cipher.decrypt(nonce, msg.ciphertext.as_ref())
            .map_err(|_| SecureChatError::Crypto("Decryption failed".into()))?;
        
        self.last_message_time = current_timestamp();
        
        Ok(plaintext)
    }
    
    fn next_sending_key(&mut self) -> Result<Vec<u8>, SecureChatError> {
        let (mk, new_ck) = kdf_ck(&self.sending_chain_key, self.sending_message_number)?;
        self.sending_chain_key = new_ck;
        Ok(mk)
    }
    
    fn next_receiving_key(&mut self) -> Result<Vec<u8>, SecureChatError> {
        let (mk, new_ck) = kdf_ck(&self.receiving_chain_key, self.receiving_message_number)?;
        self.receiving_chain_key = new_ck;
        Ok(mk)
    }
    
    fn dh_ratchet(&mut self, their_new_key: &[u8]) -> Result<(), SecureChatError> {
        self.previous_chain_length = self.sending_message_number;
        self.sending_message_number = 0;
        self.receiving_message_number = 0;
        
        let our_secret = self.our_ratchet_key.as_ref()
            .ok_or_else(|| SecureChatError::Protocol("No ratchet key available".into()))?;
        let our_secret = X25519SecretKey::from(
            our_secret.as_slice().try_into()
                .map_err(|_| SecureChatError::Protocol("Invalid ratchet key".into()))?
        );
        
        let their_pk = X25519PublicKey::from(
            their_new_key.try_into()
                .map_err(|_| SecureChatError::Protocol("Invalid peer key".into()))?
        );
        
        let dh_output = our_secret.diffie_hellman(&their_pk);
        let (new_root, receiving_ck) = kdf_ck(&self.root_key, 0)?;
        self.root_key = new_root;
        self.receiving_chain_key = receiving_ck;
        
        // Generate new DH key pair for sending
        let mut csprng = OsRng;
        let new_secret = X25519SecretKey::random_from_rng(&mut csprng);
        let new_public = X25519PublicKey::from(&new_secret);
        let new_dh = new_secret.diffie_hellman(&their_pk);
        
        let (new_root2, sending_ck) = kdf_ck(&self.root_key, 1)?;
        self.root_key = new_root2;
        self.sending_chain_key = sending_ck;
        self.our_ratchet_key = Some(new_secret.to_bytes().to_vec());
        self.their_ratchet_key = Some(their_new_key.to_vec());
        self.ratchet_step += 1;
        
        // Zeroize old key
        drop(our_secret);
        drop(dh_output);
        drop(new_dh);
        
        Ok(())
    }
}

/// Encrypted message with header for ratchet processing
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EncryptedMessage {
    pub header: MessageHeader,
    pub nonce: Vec<u8>,
    pub ciphertext: Vec<u8>,
}

/// Message header containing ratchet metadata
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MessageHeader {
    pub ratchet_key: Option<Vec<u8>>,
    pub message_number: u32,
    pub previous_chain_length: u32,
}

/// KDF for root key (ratchet step)
fn kdf_rk(
    root_key: &[u8],
    our_secret: &X25519SecretKey,
    their_public: &X25519PublicKey,
) -> Result<Vec<u8>, SecureChatError> {
    let dh = our_secret.diffie_hellman(their_public);
    let salt = blake2b_hash(root_key);
    let ikm = dh.to_bytes();
    
    let hkdf = Hkdf::<Sha256>::new(Some(&salt), &ikm);
    let mut okm = [0u8; 32];
    hkdf.expand(b"SignalDoubleRatchet", &mut okm)
        .map_err(|_| SecureChatError::Crypto("HKDF expand failed".into()))?;
    
    Ok(okm.to_vec())
}

fn kdf_rk_bob(
    root_key: &[u8],
    our_secret: &X25519SecretKey,
) -> Result<Vec<u8>, SecureChatError> {
    // Bob doesn't have their public yet - derive from initial shared secret
    let salt = blake2b_hash(root_key);
    let hkdf = Hkdf::<Sha256>::new(Some(&salt), root_key);
    let mut okm = [0u8; 32];
    hkdf.expand(b"SignalDoubleRatchetInit", &mut okm)
        .map_err(|_| SecureChatError::Crypto("HKDF expand failed".into()))?;
    Ok(okm.to_vec())
}

/// KDF for chain key -> message key + new chain key
fn kdf_ck(chain_key: &[u8], counter: u32) -> Result<(Vec<u8>, Vec<u8>), SecureChatError> {
    let mut counter_bytes = [0u8; 4];
    counter_bytes.copy_from_slice(&counter.to_be_bytes());
    
    let hkdf = Hkdf::<Sha256>::new(None, chain_key);
    let mut okm = [0u8; 64];
    hkdf.expand(&counter_bytes, &mut okm)
        .map_err(|_| SecureChatError::Crypto("Chain KDF failed".into()))?;
    
    let mk = okm[..32].to_vec();
    let ck = okm[32..].to_vec();
    Ok((mk, ck))
}

fn blake2b_hash(data: &[u8]) -> [u8; 32] {
    use blake2::Blake2b512;
    let mut hasher = Blake2b512::new();
    hasher.update(data);
    let result = hasher.finalize();
    let mut out = [0u8; 32];
    out.copy_from_slice(&result[..32]);
    out
}

fn current_timestamp() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}
