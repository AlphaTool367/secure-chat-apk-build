//! Key management utilities - shared secrets, fingerprint verification
//! 
//! # Peer Key Verification
//! - Display SAS (Short Authentication String) or QR code for manual verification
//! - Trust-on-first-use (TOFU) with explicit verification option
//! - Key change detection with user warning

use crate::SecureChatError;
use serde::{Serialize, Deserialize};
use zeroize::{Zeroize, ZeroizeOnDrop};
use sha2::{Sha256, Digest};

/// Verified peer key entry
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PeerKeyEntry {
    pub peer_id: String,
    pub verifying_key: Vec<u8>,
    pub x25519_public: Vec<u8>,
    pub first_seen: u64,
    pub last_seen: u64,
    pub verified: bool, // Explicitly verified by user (SAS/QR)
    pub trust_level: TrustLevel,
}

/// Trust levels for peer keys
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum TrustLevel {
    Untrusted = 0,    // First contact, not verified
    Tofu = 1,         // Trust on first use (default)
    Verified = 2,     // Manually verified via SAS/QR
    Blocked = 255,    // Explicitly blocked
}

/// Generate a human-verifiable fingerprint for a key
/// Returns 6 groups of 5 chars (base32-like) for easy comparison
pub fn generate_fingerprint(public_key: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(public_key);
    let hash = hasher.finalize();
    
    let mut result = String::new();
    let alphabet = b"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // Crockford base32, excludes I,L,O,0,1
    
    for i in 0..30 {
        let byte = hash[i % hash.len()];
        let idx = (byte % (alphabet.len() as u8)) as usize;
        result.push(alphabet[idx] as char);
        if i > 0 && i % 5 == 4 && i < 29 {
            result.push(' ');
        }
    }
    
    result
}

/// Generate a SAS (Short Authentication String) for verbal verification
/// Returns 3 random words from a wordlist
pub fn generate_sas(shared_secret: &[u8]) -> Vec<String> {
    let wordlist = &[
        "apple", "bravo", "chair", "delta", "eagle", "frost", "ghost", "hotel",
        "india", "joker", "kite", "lemon", "magic", "night", "ocean", "piano",
        "queen", "radio", "sword", "tiger", "union", "violet", "whale", "xray",
        "yellow", "zebra", "anchor", "bliss", "cloud", "dream", "ember", "flame",
    ];
    
    let mut result = Vec::new();
    let mut hasher = Sha256::new();
    hasher.update(shared_secret);
    let hash = hasher.finalize();
    
    for i in 0..3 {
        let idx = (hash[i] as usize) % wordlist.len();
        result.push(wordlist[idx].to_string());
    }
    
    result
}

/// Check if a key change represents a security risk
pub fn detect_key_change(
    old_entry: &PeerKeyEntry,
    new_key: &[u8],
) -> KeyChangeStatus {
    if old_entry.verifying_key == new_key {
        return KeyChangeStatus::Unchanged;
    }
    
    if old_entry.verified || old_entry.trust_level == TrustLevel::Verified {
        KeyChangeStatus::CriticalChange
    } else {
        KeyChangeStatus::PossibleMitm
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum KeyChangeStatus {
    Unchanged,
    PossibleMitm,
    CriticalChange,
}

/// In-memory key cache (not persisted - reloaded from storage on boot)
#[derive(Debug, Default)]
pub struct PeerKeyCache {
    peers: std::collections::HashMap<String, PeerKeyEntry>,
}

impl PeerKeyCache {
    pub fn new() -> Self {
        Self::default()
    }
    
    pub fn get(&self, peer_id: &str) -> Option<&PeerKeyEntry> {
        self.peers.get(peer_id)
    }
    
    pub fn insert(&mut self, entry: PeerKeyEntry) {
        self.peers.insert(entry.peer_id.clone(), entry);
    }
    
    pub fn verify_peer(&mut self, peer_id: &str) -> Result<(), SecureChatError> {
        let entry = self.peers.get_mut(peer_id)
            .ok_or_else(|| SecureChatError::Identity("Unknown peer".into()))?;
        entry.verified = true;
        entry.trust_level = TrustLevel::Verified;
        Ok(())
    }
    
    pub fn block_peer(&mut self, peer_id: &str) -> Result<(), SecureChatError> {
        let entry = self.peers.get_mut(peer_id)
            .ok_or_else(|| SecureChatError::Identity("Unknown peer".into()))?;
        entry.trust_level = TrustLevel::Blocked;
        Ok(())
    }
    
    pub fn iter(&self) -> impl Iterator<Item = &PeerKeyEntry> {
        self.peers.values()
    }
}
