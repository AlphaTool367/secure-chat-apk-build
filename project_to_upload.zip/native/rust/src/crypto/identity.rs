//! Identity management - Ed25519 keypairs with no username/email/phone
//! 
//! # Anonymity
//! - Identity is `anon_<hex(pubkey)>` - no link to real-world identity
//! - Generated purely locally, never transmitted raw
//! - Backup requires explicit user action (QR/USB export)

use crate::SecureChatError;
use crate::storage::secure_store::SecureStorage;
use ed25519_dalek::{SigningKey, VerifyingKey, Signature, Signer, Verifier};
use x25519_dalek::{PublicKey as X25519PublicKey, StaticSecret as X25519SecretKey};
use rand::rngs::OsRng;
use serde::{Serialize, Deserialize};
use zeroize::{Zeroize, ZeroizeOnDrop};
use sha2::{Sha256, Digest};
use argon2::{Argon2, password_hash::SaltString};
use chacha20poly1305::{ChaCha20Poly1305, Key, Nonce};
use chacha20poly1305::aead::{Aead, AeadCore};
use std::convert::TryInto;

/// Anonymous identity - no personal data attached
#[derive(Debug, Clone, Serialize, Deserialize, Zeroize, ZeroizeOnDrop)]
pub struct AnonymousIdentity {
    /// Display ID: anon_<first_16_chars_of_pubkey_hash>
    pub anon_id: String,
    /// Ed25519 signing key (kept in secure enclave when possible)
    #[zeroize(skip)]
    #[serde(skip)]
    pub signing_key: Option<Vec<u8>>,
    /// Ed25519 verifying key (public)
    pub verifying_key: Vec<u8>,
    /// X25519 public key for ECDH
    pub x25519_public: Vec<u8>,
    /// X25519 secret key for ECDH (kept in secure enclave)
    #[zeroize(skip)]
    #[serde(skip)]
    pub x25519_secret: Option<Vec<u8>>,
    /// Creation timestamp (for key rotation tracking)
    pub created_at: u64,
    /// Key rotation counter
    pub key_version: u32,
}

impl AnonymousIdentity {
    /// Generate a fresh anonymous identity
    pub fn generate() -> Result<Self, SecureChatError> {
        let mut csprng = OsRng;
        
        // Ed25519 identity
        let signing_key = SigningKey::generate(&mut csprng);
        let verifying_key = signing_key.verifying_key();
        
        // X25519 key exchange
        let x25519_secret = X25519SecretKey::random_from_rng(&mut csprng);
        let x25519_public = X25519PublicKey::from(&x25519_secret);
        
        // Derive anonymous ID from public key hash (no personal data)
        let mut hasher = Sha256::new();
        hasher.update(verifying_key.as_bytes());
        let hash = hasher.finalize();
        let anon_id = format!("anon_{}", hex::encode(&hash[..8]));
        
        Ok(Self {
            anon_id,
            signing_key: Some(signing_key.to_bytes().to_vec()),
            verifying_key: verifying_key.as_bytes().to_vec(),
            x25519_public: x25519_public.as_bytes().to_vec(),
            x25519_secret: Some(x25519_secret.to_bytes().to_vec()),
            created_at: current_timestamp(),
            key_version: 1,
        })
    }
    
    /// Sign a message with Ed25519
    pub fn sign(&self, message: &[u8]) -> Result<Vec<u8>, SecureChatError> {
        let sk_bytes = self.signing_key.as_ref()
            .ok_or_else(|| SecureChatError::Identity("Signing key not available".into()))?;
        let signing_key = SigningKey::from_bytes(
            sk_bytes.as_slice().try_into()
                .map_err(|_| SecureChatError::Crypto("Invalid signing key length".into()))?
        );
        let signature = signing_key.sign(message);
        Ok(signature.to_bytes().to_vec())
    }
    
    /// Verify a signature
    pub fn verify(&self, message: &[u8], signature: &[u8]) -> Result<bool, SecureChatError> {
        let vk_bytes: [u8; 32] = self.verifying_key.as_slice().try_into()
            .map_err(|_| SecureChatError::Crypto("Invalid verifying key length".into()))?;
        let verifying_key = VerifyingKey::from_bytes(&vk_bytes)
            .map_err(|e| SecureChatError::Crypto(format!("Invalid verifying key: {}", e)))?;
        let sig_bytes: [u8; 64] = signature.try_into()
            .map_err(|_| SecureChatError::Crypto("Invalid signature length".into()))?;
        let signature = Signature::from_bytes(&sig_bytes);
        
        verifying_key.verify(message, &signature)
            .map_err(|e| SecureChatError::Crypto(format!("Signature verification failed: {}", e)))?;
        Ok(true)
    }
    
    /// Perform X25519 ECDH key exchange
    pub fn ecdh(&self, peer_public: &[u8]) -> Result<Vec<u8>, SecureChatError> {
        let sk_bytes = self.x25519_secret.as_ref()
            .ok_or_else(|| SecureChatError::Identity("X25519 secret not available".into()))?;
        let secret = X25519SecretKey::from(
            sk_bytes.as_slice().try_into()
                .map_err(|_| SecureChatError::Crypto("Invalid X25519 secret length".into()))?
        );
        let peer_bytes: [u8; 32] = peer_public.try_into()
            .map_err(|_| SecureChatError::Crypto("Invalid peer public key length".into()))?;
        let peer = X25519PublicKey::from(peer_bytes);
        
        let shared = secret.diffie_hellman(&peer);
        Ok(shared.to_bytes().to_vec())
    }
    
    /// Serialize to JSON (secrets excluded by serde(skip))
    pub fn to_json(&self) -> Result<String, SecureChatError> {
        serde_json::to_string(self)
            .map_err(|e| SecureChatError::Identity(format!("Serialization failed: {}", e)))
    }
}

/// Manages identity lifecycle (generation, storage, rotation, backup)
pub struct IdentityManager {
    pub identity: AnonymousIdentity,
}

impl IdentityManager {
    /// Generate and persist a new identity
    pub fn generate(storage: &SecureStorage) -> Result<Self, SecureChatError> {
        let identity = AnonymousIdentity::generate()?;
        let encrypted_identity = Self::encrypt_identity(&identity, storage)?;
        storage.write_file("identity/identity.json.enc", &encrypted_identity)?;
        
        Ok(Self { identity })
    }
    
    /// Restore from encrypted backup data
    pub fn restore_from_backup(
        storage: &SecureStorage,
        backup_data: &[u8],
        password: &str,
    ) -> Result<Self, SecureChatError> {
        let identity = Self::decrypt_backup(backup_data, password)?;
        let encrypted_identity = Self::encrypt_identity(&identity, storage)?;
        storage.write_file("identity/identity.json.enc", &encrypted_identity)?;
        
        Ok(Self { identity })
    }
    
    /// Export encrypted backup using password-derived key
    pub fn export_backup(
        &self,
        _storage: &SecureStorage,
        password: &str,
    ) -> Result<Vec<u8>, SecureChatError> {
        let salt = SaltString::generate(&mut OsRng);
        let argon2 = Argon2::default();
        let mut key = [0u8; 32];
        
        argon2.hash_password_into(
            password.as_bytes(),
            salt.as_str().as_bytes(),
            &mut key,
        ).map_err(|e| SecureChatError::Crypto(format!("Argon2id failed: {}", e)))?;
        
        let identity_json = self.identity.to_json()?;
        let cipher = ChaCha20Poly1305::new(Key::from_slice(&key));
        let nonce = ChaCha20Poly1305::generate_nonce(&mut OsRng);
        let ciphertext = cipher.encrypt(&nonce, identity_json.as_bytes())
            .map_err(|e| SecureChatError::Crypto(format!("Encryption failed: {}", e)))?;
        
        let mut result = Vec::new();
        result.extend_from_slice(salt.as_str().as_bytes());
        result.extend_from_slice(&nonce);
        result.extend_from_slice(&ciphertext);
        
        // Zeroize key material
        key.zeroize();
        
        Ok(result)
    }
    
    fn encrypt_identity(
        identity: &AnonymousIdentity,
        storage: &SecureStorage,
    ) -> Result<Vec<u8>, SecureChatError> {
        // Use storage's master key for encryption
        let master_key = storage.master_key()?;
        let json = identity.to_json()?;
        let cipher = ChaCha20Poly1305::new(Key::from_slice(&master_key));
        let nonce = ChaCha20Poly1305::generate_nonce(&mut OsRng);
        let ciphertext = cipher.encrypt(&nonce, json.as_bytes())
            .map_err(|e| SecureChatError::Crypto(format!("Identity encryption failed: {}", e)))?;
        
        let mut result = Vec::new();
        result.extend_from_slice(&nonce);
        result.extend_from_slice(&ciphertext);
        Ok(result)
    }
    
    fn decrypt_backup(data: &[u8], password: &str) -> Result<AnonymousIdentity, SecureChatError> {
        if data.len() < 32 {
            return Err(SecureChatError::InvalidInput("Backup data too short".into()));
        }
        
        let salt = std::str::from_utf8(&data[..16])
            .map_err(|_| SecureChatError::InvalidInput("Invalid salt".into()))?;
        let nonce = Nonce::from_slice(&data[16..28]);
        let ciphertext = &data[28..];
        
        let argon2 = Argon2::default();
        let mut key = [0u8; 32];
        argon2.hash_password_into(password.as_bytes(), salt.as_bytes(), &mut key)
            .map_err(|e| SecureChatError::Crypto(format!("Argon2id failed: {}", e)))?;
        
        let cipher = ChaCha20Poly1305::new(Key::from_slice(&key));
        let plaintext = cipher.decrypt(nonce, ciphertext)
            .map_err(|_| SecureChatError::Crypto("Backup decryption failed - wrong password?".into()))?;
        
        key.zeroize();
        
        let json = String::from_utf8(plaintext)
            .map_err(|_| SecureChatError::InvalidInput("Invalid UTF-8 in backup".into()))?;
        let identity: AnonymousIdentity = serde_json::from_str(&json)
            .map_err(|e| SecureChatError::Identity(format!("Backup parse failed: {}", e)))?;
        
        Ok(identity)
    }
}

fn current_timestamp() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|_| SecureChatError::Identity("System time error".into()))
        .unwrap()
        .as_secs()
}
