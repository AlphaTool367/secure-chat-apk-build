import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'core/theme/app_theme.dart';
import 'core/services/navigation_service.dart';
import 'ui/screens/splash_screen.dart';
import 'ui/screens/home_screen.dart';
import 'ui/screens/chat_screen.dart';
import 'ui/screens/settings_screen.dart';
import 'ui/screens/identity_screen.dart';
import 'ui/screens/discovery_screen.dart';
import 'ui/blocs/app_bloc.dart';
import 'ui/blocs/chat_bloc.dart';
import 'ui/blocs/identity_bloc.dart';
import 'ui/blocs/settings_bloc.dart';

class SecureChatApp extends StatelessWidget {
  const SecureChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => AppBloc()),
        BlocProvider(create: (_) => ChatBloc()),
        BlocProvider(create: (_) => IdentityBloc()),
        BlocProvider(create: (_) => SettingsBloc()),
      ],
      child: MaterialApp(
        title: 'Secure Chat',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        navigatorKey: NavigationService.navigatorKey,
        initialRoute: '/',
        routes: {
          '/': (context) => const SplashScreen(),
          '/home': (context) => const HomeScreen(),
          '/chat': (context) => const ChatScreen(),
          '/settings': (context) => const SettingsScreen(),
          '/identity': (context) => const IdentityScreen(),
          '/discovery': (context) => const DiscoveryScreen(),
        },
      ),
    );
  }
}
