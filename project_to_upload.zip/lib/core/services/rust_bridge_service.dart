/// Rust FFI Bridge Service
/// 
/// Provides typed interface to the Rust core library via flutter_rust_bridge.
/// All cryptographic operations are delegated to the memory-safe Rust core.

import 'dart:ffi';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';

/// Exception thrown when Rust core operations fail
class RustBridgeException implements Exception {
  final String message;
  final String? code;
  
  const RustBridgeException(this.message, {this.code});
  
  @override
  String toString() => 'RustBridgeException: $message${code != null ? ' (code: $code)' : ''}';
}

/// Service for interacting with the Rust core via FFI
class RustBridgeService {
  static final RustBridgeService _instance = RustBridgeService._internal();
  factory RustBridgeService() => _instance;
  RustBridgeService._internal();
  
  bool _initialized = false;
  
  /// Initialize the Rust bridge
  Future<void> initialize() async {
    if (_initialized) return;
    
    try {
      // Initialize Rust libsodium and core
      await _initRustCore();
      _initialized = true;
    } on PlatformException catch (e) {
      throw RustBridgeException(
        'Failed to initialize Rust core: ${e.message}',
        code: e.code,
      );
    }
  }
  
  Future<void> _initRustCore() async {
    // In production, flutter_rust_bridge generates these bindings
    // This is the integration point with native/rust/src/lib.rs
  }
  
  /// Initialize secure context with new identity
  Future<SecureContext> initSecureContext(String appDir) async {
    await initialize();
    
    // FFI call to Rust: SecureContext::init(app_dir)
    // Returns handle to secure context with generated identity
    final result = await _ffiCall<Map<String, dynamic>>(
      'init_secure_context',
      {'app_dir': appDir},
    );
    
    return SecureContext(
      handle: result['handle'] as int,
      anonId: result['anon_id'] as String,
      verifyingKeyFingerprint: result['fingerprint'] as String,
    );
  }
  
  /// Restore from encrypted backup
  Future<SecureContext> restoreFromBackup(
    String appDir,
    Uint8List backupData,
    String password,
  ) async {
    await initialize();
    
    final result = await _ffiCall<Map<String, dynamic>>(
      'restore_from_backup',
      {
        'app_dir': appDir,
        'backup_data': backupData,
        'password': password,
      },
    );
    
    return SecureContext(
      handle: result['handle'] as int,
      anonId: result['anon_id'] as String,
      verifyingKeyFingerprint: result['fingerprint'] as String,
    );
  }
  
  /// Export encrypted backup
  Future<Uint8List> exportBackup(int contextHandle, String password) async {
    final result = await _ffiCall<Uint8List>(
      'export_backup',
      {
        'handle': contextHandle,
        'password': password,
      },
    );
    return result;
  }
  
  /// Sign data with identity key
  Future<Uint8List> sign(int contextHandle, Uint8List data) async {
    return await _ffiCall<Uint8List>(
      'sign',
      {'handle': contextHandle, 'data': data},
    );
  }
  
  /// Verify signature
  Future<bool> verify(
    Uint8List publicKey,
    Uint8List data,
    Uint8List signature,
  ) async {
    return await _ffiCall<bool>(
      'verify',
      {
        'public_key': publicKey,
        'data': data,
        'signature': signature,
      },
    );
  }
  
  /// Perform ECDH key exchange
  Future<Uint8List> ecdh(
    int contextHandle,
    Uint8List peerPublicKey,
  ) async {
    return await _ffiCall<Uint8List>(
      'ecdh',
      {
        'handle': contextHandle,
        'peer_public_key': peerPublicKey,
      },
    );
  }
  
  /// Initialize Double Ratchet for a peer
  Future<int> initDoubleRatchet(
    int contextHandle,
    String peerId,
    Uint8List sharedSecret,
    Uint8List peerPublicKey,
    bool isAlice,
  ) async {
    final result = await _ffiCall<int>(
      'init_double_ratchet',
      {
        'handle': contextHandle,
        'peer_id': peerId,
        'shared_secret': sharedSecret,
        'peer_public_key': peerPublicKey,
        'is_alice': isAlice,
      },
    );
    return result; // ratchet handle
  }
  
  /// Encrypt message with Double Ratchet
  Future<EncryptedMessage> encryptMessage(
    int ratchetHandle,
    Uint8List plaintext,
  ) async {
    final result = await _ffiCall<Map<String, dynamic>>(
      'encrypt_message',
      {
        'ratchet_handle': ratchetHandle,
        'plaintext': plaintext,
      },
    );
    
    return EncryptedMessage(
      header: MessageHeader(
        ratchetKey: result['header']['ratchet_key'] != null 
            ? Uint8List.fromList(result['header']['ratchet_key'] as List<int>)
            : null,
        messageNumber: result['header']['message_number'] as int,
        previousChainLength: result['header']['previous_chain_length'] as int,
      ),
      nonce: Uint8List.fromList(result['nonce'] as List<int>),
      ciphertext: Uint8List.fromList(result['ciphertext'] as List<int>),
    );
  }
  
  /// Decrypt message with Double Ratchet
  Future<Uint8List> decryptMessage(
    int ratchetHandle,
    EncryptedMessage message,
  ) async {
    return await _ffiCall<Uint8List>(
      'decrypt_message',
      {
        'ratchet_handle': ratchetHandle,
        'message': {
          'header': {
            'ratchet_key': message.header.ratchetKey?.toList(),
            'message_number': message.header.messageNumber,
            'previous_chain_length': message.header.previousChainLength,
          },
          'nonce': message.nonce.toList(),
          'ciphertext': message.ciphertext.toList(),
        },
      },
    );
  }
  
  /// Store encrypted file
  Future<void> writeFile(
    int contextHandle,
    String path,
    Uint8List data,
  ) async {
    await _ffiCall<void>(
      'write_file',
      {
        'handle': contextHandle,
        'path': path,
        'data': data,
      },
    );
  }
  
  /// Read encrypted file
  Future<Uint8List> readFile(
    int contextHandle,
    String path,
  ) async {
    return await _ffiCall<Uint8List>(
      'read_file',
      {
        'handle': contextHandle,
        'path': path,
      },
    );
  }
  
  /// Generate random bytes from Rust's secure RNG
  Future<Uint8List> secureRandom(int length) async {
    return await _ffiCall<Uint8List>(
      'secure_random',
      {'length': length},
    );
  }
  
  /// Hash data with BLAKE2b
  Future<Uint8List> hashBlake2b(Uint8List data) async {
    return await _ffiCall<Uint8List>(
      'hash_blake2b',
      {'data': data},
    );
  }
  
  /// Derive key with Argon2id
  Future<Uint8List> deriveKey(
    Uint8List password,
    Uint8List salt,
  ) async {
    return await _ffiCall<Uint8List>(
      'derive_key',
      {
        'password': password,
        'salt': salt,
      },
    );
  }
  
  // Private FFI call helper
  Future<T> _ffiCall<T>(String method, Map<String, dynamic> args) async {
    // In production, this uses flutter_rust_bridge generated bindings
    // For now, throws to indicate unimplemented in stub
    throw UnimplementedError(
      'FFI call to $method requires flutter_rust_bridge code generation. '
      'Run: flutter_rust_bridge_codegen generate'
    );
  }
}

/// Secure context handle from Rust
class SecureContext {
  final int handle;
  final String anonId;
  final String verifyingKeyFingerprint;
  
  const SecureContext({
    required this.handle,
    required this.anonId,
    required this.verifyingKeyFingerprint,
  });
}

/// Encrypted message structure
class EncryptedMessage {
  final MessageHeader header;
  final Uint8List nonce;
  final Uint8List ciphertext;
  
  const EncryptedMessage({
    required this.header,
    required this.nonce,
    required this.ciphertext,
  });
}

class MessageHeader {
  final Uint8List? ratchetKey;
  final int messageNumber;
  final int previousChainLength;
  
  const MessageHeader({
    this.ratchetKey,
    required this.messageNumber,
    required this.previousChainLength,
  });
}