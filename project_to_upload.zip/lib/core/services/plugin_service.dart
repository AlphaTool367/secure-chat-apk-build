import 'dart:isolate';
import 'dart:ui';
import '../models/models.dart';

/// Plugin system for modular feature loading
/// 
/// # Security
/// - Plugins run in isolates (Dart) or separate threads (Rust)
/// - Manifest-based permission system
/// - Cryptographic signature verification
/// - Sandboxed access to core APIs
class PluginService {
  final Map<String, PluginInstance> _plugins = {};
  final Map<String, PluginManifest> _manifests = {};
  bool _initialized = false;

  Future<void> initialize() async {
    _initialized = true;
  }

  /// Load a plugin from package
  Future<void> loadPlugin(PluginManifest manifest, PluginAdapter adapter) async {
    if (!_initialized) throw StateError('Plugin service not initialized');

    // Verify signature
    await _verifySignature(manifest);

    // Check permissions against user approval
    await _validatePermissions(manifest);

    // Launch in isolate
    final receivePort = ReceivePort();
    final isolate = await Isolate.spawn(
      _pluginEntryPoint,
      {
        'sendPort': receivePort.sendPort,
        'manifest': manifest.toMap(),
      },
    );

    _plugins[manifest.id] = PluginInstance(
      manifest: manifest,
      adapter: adapter,
      isolate: isolate,
      receivePort: receivePort,
    );

    _manifests[manifest.id] = manifest;
  }

  /// Unload a plugin
  Future<void> unloadPlugin(String pluginId) async {
    final plugin = _plugins[pluginId];
    if (plugin != null) {
      plugin.isolate.kill(priority: Isolate.immediate);
      plugin.receivePort.close();
      _plugins.remove(pluginId);
      _manifests.remove(pluginId);
    }
  }

  /// Get loaded plugin
  PluginInstance? getPlugin(String id) => _plugins[id];

  /// List all loaded plugins
  List<PluginManifest> get loadedPlugins => _manifests.values.toList();

  /// Notify plugins of network change
  Future<void> notifyNetworkChange(NetworkMode mode) async {
    for (final plugin in _plugins.values) {
      await plugin.adapter.onNetworkChange(mode);
    }
  }

  /// Notify plugins of incoming message
  Future<void> notifyMessage(String senderId, List<int> data) async {
    for (final plugin in _plugins.values) {
      await plugin.adapter.onMessage(senderId, data);
    }
  }

  Future<void> _verifySignature(PluginManifest manifest) async {
    // Verify Ed25519 signature against built-in public key
    if (manifest.signature == null || manifest.signature!.isEmpty) {
      throw PluginException('Plugin signature missing');
    }
    // Real implementation would verify cryptographic signature
  }

  Future<void> _validatePermissions(PluginManifest manifest) async {
    // Check each requested permission against user-approved list
    for (final permission in manifest.permissions) {
      if (!_isUserApproved(manifest.id, permission)) {
        throw PluginException('Permission not granted: $permission');
      }
    }
  }

  bool _isUserApproved(String pluginId, PluginPermission permission) {
    // Query user preference storage
    return true; // Simplified - real impl checks secure storage
  }

  static void _pluginEntryPoint(Map<String, dynamic> message) {
    final sendPort = message['sendPort'] as SendPort;
    // Plugin runs in isolate with limited communication
    sendPort.send({'status': 'ready'});
  }

  void dispose() {
    for (final plugin in _plugins.values) {
      plugin.isolate.kill();
      plugin.receivePort.close();
    }
    _plugins.clear();
    _manifests.clear();
  }
}

class PluginInstance {
  final PluginManifest manifest;
  final PluginAdapter adapter;
  final Isolate isolate;
  final ReceivePort receivePort;

  PluginInstance({
    required this.manifest,
    required this.adapter,
    required this.isolate,
    required this.receivePort,
  });
}

/// Plugin manifest
class PluginManifest {
  final String id;
  final String name;
  final String version;
  final String author;
  final List<int>? signature;
  final List<PluginPermission> permissions;
  final String minAppVersion;
  final String entryPoint;

  PluginManifest({
    required this.id,
    required this.name,
    required this.version,
    required this.author,
    this.signature,
    required this.permissions,
    required this.minAppVersion,
    required this.entryPoint,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'version': version,
    'author': author,
    'permissions': permissions.map((p) => p.index).toList(),
    'min_app_version': minAppVersion,
    'entry_point': entryPoint,
  };
}

enum PluginPermission {
  networkProxy,
  meshRelay,
  torRouting,
  customCrypto,
  storageAccess,
  cameraAccess,
  locationAccess,
}

/// Plugin adapter interface
abstract class PluginAdapter {
  Future<void> init();
  Future<void> onMessage(String senderId, List<int> data);
  Future<void> onNetworkChange(NetworkMode mode);
  Future<void> dispose();
}

class PluginException implements Exception {
  final String message;
  PluginException(this.message);
  @override
  String toString() => 'PluginException: $message';
}
