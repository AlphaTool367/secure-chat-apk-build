import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import '../models/models.dart';
import 'crypto_service.dart';
import 'storage_service.dart';
import 'rust_bridge_service.dart';

/// Identity management service
/// 
/// Handles anonymous identity lifecycle:
/// - Generation (no signup required)
/// - Storage (OS secure enclave)
/// - Backup/restore (QR/USB export)
/// - Key rotation
/// - Peer verification
class IdentityService {
  final CryptoService _crypto = CryptoService();
  final StorageService _storage = StorageService();
  
  AnonymousIdentity? _identity;
  final Map<String, Peer> _peers = {};
  
  AnonymousIdentity? get currentIdentity => _identity;
  List<Peer> get peers => _peers.values.toList();

  /// Initialize with new identity or load existing
  Future<AnonymousIdentity> initialize(String appDir) async {
    // Try to load existing identity first
    final existing = await _loadExistingIdentity(appDir);
    if (existing != null) {
      _identity = existing;
      return existing;
    }
    
    // Generate fresh anonymous identity
    _identity = await _crypto.initialize(appDir);
    await _saveIdentity(_identity!);
    return _identity!;
  }

  /// Restore identity from encrypted backup
  Future<AnonymousIdentity> restoreBackup(
    String appDir,
    Uint8List backupData,
    String password,
  ) async {
    _identity = await _crypto.restoreBackup(appDir, backupData, password);
    await _saveIdentity(_identity!);
    return _identity!;
  }

  /// Export identity backup
  Future<Uint8List> exportBackup(String password) async {
    if (_identity == null) throw StateError('No identity');
    return _crypto.exportBackup(password);
  }

  /// Add a discovered peer
  Future<Peer> addPeer({
    required String anonId,
    required String fingerprint,
    required String x25519PublicKey,
    String? nickname,
  }) async {
    final peer = Peer(
      anonId: anonId,
      fingerprint: fingerprint,
      nickname: nickname,
      firstSeen: DateTime.now(),
      lastSeen: DateTime.now(),
      verified: false,
      trustLevel: TrustLevel.tofu,
      x25519PublicKey: x25519PublicKey,
    );
    
    _peers[anonId] = peer;
    await _savePeers();
    return peer;
  }

  /// Verify a peer via SAS/QR fingerprint
  Future<void> verifyPeer(String anonId) async {
    final peer = _peers[anonId];
    if (peer == null) throw StateError('Unknown peer');
    
    _peers[anonId] = Peer(
      anonId: peer.anonId,
      fingerprint: peer.fingerprint,
      nickname: peer.nickname,
      firstSeen: peer.firstSeen,
      lastSeen: peer.lastSeen,
      verified: true,
      trustLevel: TrustLevel.verified,
      x25519PublicKey: peer.x25519PublicKey,
    );
    
    await _savePeers();
  }

  /// Block a peer
  Future<void> blockPeer(String anonId) async {
    final peer = _peers[anonId];
    if (peer == null) return;
    
    _peers[anonId] = Peer(
      anonId: peer.anonId,
      fingerprint: peer.fingerprint,
      nickname: peer.nickname,
      firstSeen: peer.firstSeen,
      lastSeen: peer.lastSeen,
      verified: peer.verified,
      trustLevel: TrustLevel.blocked,
      x25519PublicKey: peer.x25519PublicKey,
    );
    
    await _savePeers();
  }

  /// Get peer by ID
  Peer? getPeer(String anonId) => _peers[anonId];

  /// Generate SAS for verbal verification
  Future<List<String>> generateSas(String peerAnonId) async {
    final peer = _peers[peerAnonId];
    if (peer == null) throw StateError('Unknown peer');
    
    // Derive shared secret via ECDH
    final sharedSecret = await _crypto.ecdh(
      Uint8List.fromList(utf8.encode(peer.x25519PublicKey)),
    );
    
    return _crypto.generateSas(sharedSecret);
  }

  Future<AnonymousIdentity?> _loadExistingIdentity(String appDir) async {
    try {
      // Check if identity exists in secure storage
      final identityJson = await _storage.readFile(0, 'identity/identity.json.enc');
      final json = jsonDecode(utf8.decode(identityJson));
      return AnonymousIdentity.fromJson(json);
    } catch (e) {
      return null;
    }
  }

  Future<void> _saveIdentity(AnonymousIdentity identity) async {
    final json = jsonEncode(identity.toJson());
    await _storage.writeFile(0, 'identity/identity.json.enc', Uint8List.fromList(utf8.encode(json)));
  }

  Future<void> _savePeers() async {
    final peersList = _peers.values.map((p) => {
      'anon_id': p.anonId,
      'fingerprint': p.fingerprint,
      'nickname': p.nickname,
      'first_seen': p.firstSeen.millisecondsSinceEpoch,
      'last_seen': p.lastSeen.millisecondsSinceEpoch,
      'verified': p.verified,
      'trust_level': p.trustLevel.index,
      'x25519_public': p.x25519PublicKey,
    }).toList();
    
    final json = jsonEncode(peersList);
    await _storage.writeFile(0, 'identity/peers.json.enc', Uint8List.fromList(utf8.encode(json)));
  }
}
