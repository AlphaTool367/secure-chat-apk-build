import 'dart:async';
import 'dart:typed_data';
import '../models/models.dart';

/// Network service managing all P2P transports
/// 
/// # Transport Modes
/// - BLE Direct: Nearby offline (10-100m)
/// - WiFi Direct: Local network mesh
/// - libp2p: Online P2P (optional, no central servers)
/// - Tor: Plugin-based routing for IP masking
class NetworkService {
  final _connectionController = StreamController<ConnectionStatus>.broadcast();
  final _messageController = StreamController<Map<String, dynamic>>.broadcast();
  final Map<String, ConnectionStatus> _peerConnections = {};
  final Map<String, TransportAdapter> _transports = {};

  Stream<ConnectionStatus> get connectionStream => _connectionController.stream;
  Stream<Map<String, dynamic>> get messageStream => _messageController.stream;

  bool _initialized = false;
  AppSettings? _settings;

  Future<void> initialize(AppSettings settings) async {
    _settings = settings;
    
    // Register transports based on settings
    if (settings.bleEnabled) {
      _transports['ble'] = BleTransportAdapter();
    }
    if (settings.wifiDirectEnabled) {
      _transports['wifi_direct'] = WifiDirectTransportAdapter();
    }
    if (settings.meshRelayEnabled) {
      _transports['mesh'] = MeshTransportAdapter();
    }
    if (settings.torModeEnabled) {
      _transports['tor'] = TorTransportAdapter();
    }

    // Initialize all registered transports
    for (final transport in _transports.values) {
      await transport.init();
    }

    _initialized = true;
  }

  /// Start peer discovery on all enabled transports
  Future<void> startDiscovery() async {
    for (final transport in _transports.values) {
      await transport.startDiscovery();
    }
  }

  /// Stop discovery
  Future<void> stopDiscovery() async {
    for (final transport in _transports.values) {
      await transport.stopDiscovery();
    }
  }

  /// Connect to a specific peer
  Future<void> connect(String peerId, NetworkMode mode, String address) async {
    final transport = _transports.values.firstWhere(
      (t) => t.mode == mode,
      orElse: () => throw StateError('Transport for $mode not available'),
    );
    
    await transport.connect(peerId, address);
    
    final status = ConnectionStatus(
      mode: mode,
      state: ConnectionState.connected,
      peerId: peerId,
      connectedSince: DateTime.now(),
    );
    _peerConnections[peerId] = status;
    _connectionController.add(status);
  }

  /// Disconnect from peer
  Future<void> disconnect(String peerId) async {
    for (final transport in _transports.values) {
      if (transport.isConnectedTo(peerId)) {
        await transport.disconnect(peerId);
      }
    }
    
    final status = ConnectionStatus(
      mode: NetworkMode.bleDirect,
      state: ConnectionState.disconnected,
      peerId: peerId,
    );
    _peerConnections[peerId] = status;
    _connectionController.add(status);
  }

  /// Send encrypted data to peer
  Future<void> send(String peerId, Uint8List encryptedData) async {
    for (final transport in _transports.values) {
      if (transport.isConnectedTo(peerId)) {
        await transport.send(peerId, encryptedData);
        return;
      }
    }
    throw StateError('No active connection to $peerId');
  }

  /// Get connection state for peer
  ConnectionState getConnectionState(String peerId) {
    return _peerConnections[peerId]?.state ?? ConnectionState.disconnected;
  }

  /// Shutdown all transports
  Future<void> shutdown() async {
    for (final transport in _transports.values) {
      await transport.shutdown();
    }
    _transports.clear();
    _peerConnections.clear();
  }

  void dispose() {
    _connectionController.close();
    _messageController.close();
  }
}

/// Abstract transport adapter
abstract class TransportAdapter {
  NetworkMode get mode;
  Future<void> init();
  Future<void> startDiscovery();
  Future<void> stopDiscovery();
  Future<void> connect(String peerId, String address);
  Future<void> disconnect(String peerId);
  Future<void> send(String peerId, Uint8List data);
  bool isConnectedTo(String peerId);
  Future<void> shutdown();
}

/// BLE transport implementation (delegates to flutter_blue_plus)
class BleTransportAdapter implements TransportAdapter {
  @override
  NetworkMode get mode => NetworkMode.bleDirect;

  final _connectedPeers = <String>{};

  @override
  Future<void> init() async {
    // Initialize BLE via flutter_blue_plus
  }

  @override
  Future<void> startDiscovery() async {
    // Start BLE scan
  }

  @override
  Future<void> stopDiscovery() async {
    // Stop BLE scan
  }

  @override
  Future<void> connect(String peerId, String address) async {
    _connectedPeers.add(peerId);
  }

  @override
  Future<void> disconnect(String peerId) async {
    _connectedPeers.remove(peerId);
  }

  @override
  Future<void> send(String peerId, Uint8List data) async {
    // Send via BLE characteristic
  }

  @override
  bool isConnectedTo(String peerId) => _connectedPeers.contains(peerId);

  @override
  Future<void> shutdown() async {
    _connectedPeers.clear();
  }
}

/// WiFi Direct transport adapter
class WifiDirectTransportAdapter implements TransportAdapter {
  @override
  NetworkMode get mode => NetworkMode.wifiDirect;

  final _connectedPeers = <String>{};

  @override
  Future<void> init() async {}
  @override
  Future<void> startDiscovery() async {}
  @override
  Future<void> stopDiscovery() async {}
  @override
  Future<void> connect(String peerId, String address) async {
    _connectedPeers.add(peerId);
  }
  @override
  Future<void> disconnect(String peerId) async {
    _connectedPeers.remove(peerId);
  }
  @override
  Future<void> send(String peerId, Uint8List data) async {}
  @override
  bool isConnectedTo(String peerId) => _connectedPeers.contains(peerId);
  @override
  Future<void> shutdown() async {
    _connectedPeers.clear();
  }
}

/// Mesh relay transport (multi-hop)
class MeshTransportAdapter implements TransportAdapter {
  @override
  NetworkMode get mode => NetworkMode.localMesh;

  final _connectedPeers = <String>{};

  @override
  Future<void> init() async {}
  @override
  Future<void> startDiscovery() async {}
  @override
  Future<void> stopDiscovery() async {}
  @override
  Future<void> connect(String peerId, String address) async {
    _connectedPeers.add(peerId);
  }
  @override
  Future<void> disconnect(String peerId) async {
    _connectedPeers.remove(peerId);
  }
  @override
  Future<void> send(String peerId, Uint8List data) async {}
  @override
  bool isConnectedTo(String peerId) => _connectedPeers.contains(peerId);
  @override
  Future<void> shutdown() async {
    _connectedPeers.clear();
  }
}

/// Tor proxy transport (via TorQ plugin)
class TorTransportAdapter implements TransportAdapter {
  @override
  NetworkMode get mode => NetworkMode.torProxy;

  final _connectedPeers = <String>{};

  @override
  Future<void> init() async {}
  @override
  Future<void> startDiscovery() async {}
  @override
  Future<void> stopDiscovery() async {}
  @override
  Future<void> connect(String peerId, String address) async {
    _connectedPeers.add(peerId);
  }
  @override
  Future<void> disconnect(String peerId) async {
    _connectedPeers.remove(peerId);
  }
  @override
  Future<void> send(String peerId, Uint8List data) async {}
  @override
  bool isConnectedTo(String peerId) => _connectedPeers.contains(peerId);
  @override
  Future<void> shutdown() async {
    _connectedPeers.clear();
  }
}
