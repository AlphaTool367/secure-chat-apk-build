import 'dart:typed_data';
import 'rust_bridge_service.dart';
import '../models/models.dart';

/// High-level cryptographic service
/// 
/// Wraps Rust core operations in application-friendly methods.
/// No raw key material exposed to Dart layer.
class CryptoService {
  final RustBridgeService _bridge = RustBridgeService();
  SecureContext? _context;
  final Map<String, int> _ratchetHandles = {};

  bool get isInitialized => _context != null;
  SecureContext? get context => _context;

  /// Initialize with new identity
  Future<AnonymousIdentity> initialize(String appDir) async {
    _context = await _bridge.initSecureContext(appDir);
    return _toIdentity(_context!);
  }

  /// Restore from backup
  Future<AnonymousIdentity> restoreBackup(
    String appDir,
    Uint8List backupData,
    String password,
  ) async {
    _context = await _bridge.restoreFromBackup(appDir, backupData, password);
    return _toIdentity(_context!);
  }

  /// Export encrypted backup
  Future<Uint8List> exportBackup(String password) async {
    if (_context == null) throw StateError('Crypto not initialized');
    return _bridge.exportBackup(_context!.handle, password);
  }

  /// Sign data with identity key
  Future<Uint8List> sign(Uint8List data) async {
    if (_context == null) throw StateError('Crypto not initialized');
    return _bridge.sign(_context!.handle, data);
  }

  /// Verify peer signature
  Future<bool> verifyPeer(
    Uint8List publicKey,
    Uint8List data,
    Uint8List signature,
  ) async {
    return _bridge.verify(publicKey, data, signature);
  }

  /// Establish secure channel with peer (X25519 ECDH + Double Ratchet init)
  Future<void> establishChannel(
    String peerId,
    Uint8List peerPublicKey,
    bool isInitiator,
  ) async {
    if (_context == null) throw StateError('Crypto not initialized');

    final sharedSecret = await _bridge.ecdh(_context!.handle, peerPublicKey);

    final handle = await _bridge.initDoubleRatchet(
      _context!.handle,
      peerId,
      sharedSecret,
      peerPublicKey,
      isInitiator,
    );

    _ratchetHandles[peerId] = handle;
  }

  /// Encrypt message for peer
  Future<EncryptedMessage> encryptForPeer(
    String peerId,
    Uint8List plaintext,
  ) async {
    final handle = _ratchetHandles[peerId];
    if (handle == null) {
      throw StateError('No secure channel established for $peerId');
    }
    return _bridge.encryptMessage(handle, plaintext);
  }

  /// Decrypt message from peer
  Future<Uint8List> decryptFromPeer(
    String peerId,
    EncryptedMessage message,
  ) async {
    final handle = _ratchetHandles[peerId];
    if (handle == null) {
      throw StateError('No secure channel established for $peerId');
    }
    return _bridge.decryptMessage(handle, message);
  }

  /// Generate human-verifiable fingerprint
  String generateFingerprint(Uint8List publicKey) {
    // Use Rust's Crockford Base32 implementation
    return _bridge.hashBlake2b(publicKey).then((hash) {
      return _formatFingerprint(hash);
    }) as String;
  }

  /// Generate SAS (Short Authentication String) for verbal verification
  Future<List<String>> generateSas(Uint8List sharedSecret) async {
    final hash = await _bridge.hashBlake2b(sharedSecret);
    return _deriveSasWords(hash);
  }

  /// Secure random bytes
  Future<Uint8List> randomBytes(int length) => _bridge.secureRandom(length);

  AnonymousIdentity _toIdentity(SecureContext ctx) {
    return AnonymousIdentity(
      anonId: ctx.anonId,
      verifyingKeyFingerprint: ctx.verifyingKeyFingerprint,
      x25519PublicKey: '', // Retrieved from Rust on demand
      createdAt: DateTime.now(),
      keyVersion: 1,
    );
  }

  String _formatFingerprint(Uint8List hash) {
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final result = StringBuffer();
    for (int i = 0; i < 30; i++) {
      final idx = hash[i % hash.length] % alphabet.length;
      result.write(alphabet[idx]);
      if (i > 0 && i % 5 == 4 && i < 29) result.write(' ');
    }
    return result.toString();
  }

  List<String> _deriveSasWords(Uint8List hash) {
    const wordlist = [
      'apple', 'bravo', 'chair', 'delta', 'eagle', 'frost', 'ghost', 'hotel',
      'india', 'joker', 'kite', 'lemon', 'magic', 'night', 'ocean', 'piano',
      'queen', 'radio', 'sword', 'tiger', 'union', 'violet', 'whale', 'xray',
      'yellow', 'zebra', 'anchor', 'bliss', 'cloud', 'dream', 'ember', 'flame',
    ];
    return [
      wordlist[hash[0] % wordlist.length],
      wordlist[hash[1] % wordlist.length],
      wordlist[hash[2] % wordlist.length],
    ];
  }
}
