import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as path;
import '../models/models.dart';
import 'rust_bridge_service.dart';

/// Local storage service - no cloud sync, no telemetry
/// 
/// # Structure
/// /app_data/
///   identity/
///   chats/<peer_id>/messages.db
///   media/cache/ (auto-wiped)
///   media/vault/
///   config/settings.json.enc
class StorageService {
  final _secureStorage = const FlutterSecureStorage(
    aOptions: AndroidOptions(
      encryptedSharedPreferences: true,
      keyCipherAlgorithm: KeyCipherAlgorithm.RSA_ECB_PKCS1Padding,
      storageCipherAlgorithm: StorageCipherAlgorithm.AES_GCM_NoPadding,
    ),
    iOptions: IOSOptions(
      accountName: 'secure_chat_account',
      accessibility: KeychainAccessibility.whenUnlockedThisDeviceOnly,
    ),
  );
  
  final RustBridgeService _bridge = RustBridgeService();
  String? _appDir;
  int? _contextHandle;
  
  Future<String> get _appDataDir async {
    _appDir ??= (await getApplicationDocumentsDirectory()).path;
    return _appDir!;
  }

  /// Store master key in OS secure enclave
  Future<void> storeMasterKey(Uint8List key) async {
    await _secureStorage.write(
      key: 'master_key',
      value: base64Encode(key),
    );
  }

  /// Retrieve master key from OS secure enclave
  Future<Uint8List?> getMasterKey() async {
    final encoded = await _secureStorage.read(key: 'master_key');
    if (encoded == null) return null;
    return base64Decode(encoded);
  }

  /// Delete all secure storage (logout / app reset)
  Future<void> deleteAll() async {
    await _secureStorage.deleteAll();
    final dir = Directory(await _appDataDir);
    if (await dir.exists()) {
      await dir.delete(recursive: true);
    }
  }

  /// Save settings (encrypted)
  Future<void> saveSettings(AppSettings settings) async {
    final dir = await _appDataDir;
    final json = jsonEncode(settings.toJson());
    final bytes = Uint8List.fromList(utf8.encode(json));
    
    // Write through Rust encrypted storage
    await _bridge.writeFile(_contextHandle!, 'config/settings.json.enc', bytes);
  }

  /// Load settings (decrypted)
  Future<AppSettings> loadSettings() async {
    try {
      final bytes = await _bridge.readFile(_contextHandle!, 'config/settings.json.enc');
      final json = utf8.decode(bytes);
      return AppSettings.fromJson(jsonDecode(json));
    } catch (e) {
      return const AppSettings(); // Default settings
    }
  }

  /// Open per-peer chat database
  Future<Database> openChatDatabase(String peerId) async {
    final dir = await _appDataDir;
    final dbPath = path.join(dir, 'chats', _sanitize(peerId), 'messages.db');
    
    await Directory(path.dirname(dbPath)).create(recursive: true);
    
    return openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE messages (
            id TEXT PRIMARY KEY,
            timestamp INTEGER NOT NULL,
            sender_id TEXT NOT NULL,
            direction INTEGER NOT NULL,
            encrypted_payload BLOB NOT NULL,
            message_type INTEGER NOT NULL,
            read INTEGER NOT NULL DEFAULT 0,
            delivered INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE INDEX idx_messages_time ON messages(timestamp)
        ''');
        await db.execute('''
          CREATE TABLE attachments (
            id TEXT PRIMARY KEY,
            message_id TEXT NOT NULL,
            filename TEXT,
            file_size INTEGER,
            encrypted_path TEXT,
            encryption_iv TEXT
          )
        ''');
      },
    );
  }

  /// Store message in peer database
  Future<void> storeMessage(String peerId, ChatMessage message) async {
    final db = await openChatDatabase(peerId);
    try {
      await db.insert('messages', {
        'id': message.id,
        'timestamp': message.timestamp.millisecondsSinceEpoch,
        'sender_id': message.senderId,
        'direction': message.direction == MessageDirection.incoming ? 0 : 1,
        'encrypted_payload': utf8.encode(message.content),
        'message_type': message.type.index,
        'read': message.read ? 1 : 0,
        'delivered': message.delivered ? 1 : 0,
      });
    } finally {
      await db.close();
    }
  }

  /// Get messages for peer
  Future<List<ChatMessage>> getMessages(String peerId, {int limit = 100, int offset = 0}) async {
    final db = await openChatDatabase(peerId);
    try {
      final rows = await db.query(
        'messages',
        orderBy: 'timestamp DESC',
        limit: limit,
        offset: offset,
      );
      
      return rows.map((row) => ChatMessage(
        id: row['id'] as String,
        senderId: row['sender_id'] as String,
        content: utf8.decode(row['encrypted_payload'] as List<int>),
        timestamp: DateTime.fromMillisecondsSinceEpoch(row['timestamp'] as int),
        direction: (row['direction'] as int) == 0 
            ? MessageDirection.incoming 
            : MessageDirection.outgoing,
        type: MessageType.values[row['message_type'] as int],
        read: (row['read'] as int) == 1,
        delivered: (row['delivered'] as int) == 1,
      )).toList();
    } finally {
      await db.close();
    }
  }

  /// Mark messages as read
  Future<void> markRead(String peerId, List<String> messageIds) async {
    final db = await openChatDatabase(peerId);
    try {
      final placeholders = List.filled(messageIds.length, '?').join(',');
      await db.rawUpdate(
        'UPDATE messages SET read = 1 WHERE id IN ($placeholders)',
        messageIds,
      );
    } finally {
      await db.close();
    }
  }

  /// Store encrypted attachment
  Future<void> storeAttachment(String mediaId, Uint8List encryptedData) async {
    final dir = await _appDataDir;
    final vaultDir = Directory(path.join(dir, 'media', 'vault'));
    await vaultDir.create(recursive: true);
    
    final file = File(path.join(vaultDir.path, '$mediaId.enc'));
    await file.writeAsBytes(encryptedData, flush: true);
  }

  /// Read encrypted attachment
  Future<Uint8List> readAttachment(String mediaId) async {
    final dir = await _appDataDir;
    final file = File(path.join(dir, 'media', 'vault', '$mediaId.enc'));
    return file.readAsBytes();
  }

  /// Store file in decrypted cache (auto-wiped)
  Future<File> cacheFile(String name, Uint8List data) async {
    final dir = await _appDataDir;
    final cacheDir = Directory(path.join(dir, 'media', 'cache'));
    await cacheDir.create(recursive: true);
    
    final file = File(path.join(cacheDir.path, name));
    await file.writeAsBytes(data, flush: true);
    return file;
  }

  /// Wipe all cached decrypted files
  Future<void> wipeCache() async {
    final dir = await _appDataDir;
    final cacheDir = Directory(path.join(dir, 'media', 'cache'));
    if (await cacheDir.exists()) {
      for (final entity in await cacheDir.list().toList()) {
        if (entity is File) {
          await _secureDelete(entity);
        }
      }
    }
  }

  /// Secure file deletion (overwrite then delete)
  Future<void> _secureDelete(File file) async {
    try {
      final size = await file.length();
      for (int pass = 0; pass < 3; pass++) {
        final zeros = Uint8List(size);
        await file.writeAsBytes(zeros, flush: true);
      }
      await file.delete();
    } catch (e) {
      // Best effort deletion
      try { await file.delete(); } catch (_) {}
    }
  }

  String _sanitize(String name) {
    return name.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_');
  }
}
