/// Anonymous identity model
/// 
/// No personal data - only cryptographic identifiers
class AnonymousIdentity {
  final String anonId;
  final String verifyingKeyFingerprint;
  final String x25519PublicKey;
  final DateTime createdAt;
  final int keyVersion;

  const AnonymousIdentity({
    required this.anonId,
    required this.verifyingKeyFingerprint,
    required this.x25519PublicKey,
    required this.createdAt,
    required this.keyVersion,
  });

  factory AnonymousIdentity.fromJson(Map<String, dynamic> json) {
    return AnonymousIdentity(
      anonId: json['anon_id'] as String,
      verifyingKeyFingerprint: json['verifying_key_fingerprint'] as String,
      x25519PublicKey: json['x25519_public'] as String,
      createdAt: DateTime.fromMillisecondsSinceEpoch((json['created_at'] as int) * 1000),
      keyVersion: json['key_version'] as int,
    );
  }

  Map<String, dynamic> toJson() => {
    'anon_id': anonId,
    'verifying_key_fingerprint': verifyingKeyFingerprint,
    'x25519_public': x25519PublicKey,
    'created_at': createdAt.millisecondsSinceEpoch ~/ 1000,
    'key_version': keyVersion,
  };
}

/// Peer contact
class Peer {
  final String anonId;
  final String fingerprint;
  final String? nickname;
  final DateTime firstSeen;
  final DateTime lastSeen;
  final bool verified;
  final TrustLevel trustLevel;
  final String x25519PublicKey;

  const Peer({
    required this.anonId,
    required this.fingerprint,
    this.nickname,
    required this.firstSeen,
    required this.lastSeen,
    required this.verified,
    required this.trustLevel,
    required this.x25519PublicKey,
  });

  String get displayName => nickname ?? anonId;
}

enum TrustLevel {
  untrusted,
  tofu,
  verified,
  blocked,
}

/// Chat message
class ChatMessage {
  final String id;
  final String senderId;
  final String content;
  final DateTime timestamp;
  final MessageDirection direction;
  final MessageType type;
  final bool read;
  final bool delivered;
  final String? mediaPath;
  final int? mediaSize;

  const ChatMessage({
    required this.id,
    required this.senderId,
    required this.content,
    required this.timestamp,
    required this.direction,
    required this.type,
    this.read = false,
    this.delivered = false,
    this.mediaPath,
    this.mediaSize,
  });
}

enum MessageDirection { incoming, outgoing }

enum MessageType { text, image, video, document, audio, location }

/// Chat conversation
class Chat {
  final String peerId;
  final String peerDisplayName;
  final String? peerFingerprint;
  final List<ChatMessage> messages;
  final int unreadCount;
  final DateTime lastMessageTime;
  final bool isVerified;

  const Chat({
    required this.peerId,
    required this.peerDisplayName,
    this.peerFingerprint,
    required this.messages,
    required this.unreadCount,
    required this.lastMessageTime,
    required this.isVerified,
  });
}

/// Network connection status
class ConnectionStatus {
  final NetworkMode mode;
  final ConnectionState state;
  final String? peerId;
  final DateTime? connectedSince;

  const ConnectionStatus({
    required this.mode,
    required this.state,
    this.peerId,
    this.connectedSince,
  });
}

enum NetworkMode { bleDirect, wifiDirect, localMesh, libp2p, torProxy }

enum ConnectionState { disconnected, discovering, connecting, connected, authenticated }

/// App settings (all local, no cloud sync)
class AppSettings {
  final bool bleEnabled;
  final bool wifiDirectEnabled;
  final bool meshRelayEnabled;
  final bool torModeEnabled;
  final bool requireVerification;
  final int selfDestructTimer;
  final bool metadataStripping;
  final bool screenshotProtection;
  final bool biometricsRequired;

  const AppSettings({
    this.bleEnabled = true,
    this.wifiDirectEnabled = true,
    this.meshRelayEnabled = false,
    this.torModeEnabled = false,
    this.requireVerification = true,
    this.selfDestructTimer = 0,
    this.metadataStripping = true,
    this.screenshotProtection = true,
    this.biometricsRequired = false,
  });

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    return AppSettings(
      bleEnabled: json['ble_enabled'] ?? true,
      wifiDirectEnabled: json['wifi_direct_enabled'] ?? true,
      meshRelayEnabled: json['mesh_relay_enabled'] ?? false,
      torModeEnabled: json['tor_mode_enabled'] ?? false,
      requireVerification: json['require_verification'] ?? true,
      selfDestructTimer: json['self_destruct_timer'] ?? 0,
      metadataStripping: json['metadata_stripping'] ?? true,
      screenshotProtection: json['screenshot_protection'] ?? true,
      biometricsRequired: json['biometrics_required'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
    'ble_enabled': bleEnabled,
    'wifi_direct_enabled': wifiDirectEnabled,
    'mesh_relay_enabled': meshRelayEnabled,
    'tor_mode_enabled': torModeEnabled,
    'require_verification': requireVerification,
    'self_destruct_timer': selfDestructTimer,
    'metadata_stripping': metadataStripping,
    'screenshot_protection': screenshotProtection,
    'biometrics_required': biometricsRequired,
  };

  AppSettings copyWith({
    bool? bleEnabled,
    bool? wifiDirectEnabled,
    bool? meshRelayEnabled,
    bool? torModeEnabled,
    bool? requireVerification,
    int? selfDestructTimer,
    bool? metadataStripping,
    bool? screenshotProtection,
    bool? biometricsRequired,
  }) {
    return AppSettings(
      bleEnabled: bleEnabled ?? this.bleEnabled,
      wifiDirectEnabled: wifiDirectEnabled ?? this.wifiDirectEnabled,
      meshRelayEnabled: meshRelayEnabled ?? this.meshRelayEnabled,
      torModeEnabled: torModeEnabled ?? this.torModeEnabled,
      requireVerification: requireVerification ?? this.requireVerification,
      selfDestructTimer: selfDestructTimer ?? this.selfDestructTimer,
      metadataStripping: metadataStripping ?? this.metadataStripping,
      screenshotProtection: screenshotProtection ?? this.screenshotProtection,
      biometricsRequired: biometricsRequired ?? this.biometricsRequired,
    );
  }
}
