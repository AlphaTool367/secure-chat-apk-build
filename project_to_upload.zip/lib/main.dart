import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app.dart';
import 'core/services/dependency_injection.dart';

/// Entry point for Secure Chat application
/// 
/// # Security Initialization
/// - Locks to portrait to prevent shoulder surfing in landscape
/// - Restricts screenshot/recording on Android
/// - Initializes Rust FFI bridge
/// - Sets up secure logging (no crash reporting, no telemetry)
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Security: Lock to portrait orientation
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // Security: Prevent screenshots and screen recording (Android)
  SystemChrome.setEnabledSystemUIMode(
    SystemUiMode.edgeToEdge,
    overlays: [SystemUiOverlay.top, SystemUiOverlay.bottom],
  );
  
  // Initialize dependency injection
  configureDependencies();
  
  runApp(const SecureChatApp());
}
