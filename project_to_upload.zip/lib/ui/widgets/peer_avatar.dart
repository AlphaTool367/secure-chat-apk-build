import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class PeerAvatar extends StatelessWidget {
  final String peerId;
  final String displayName;
  final double size;
  final bool isVerified;

  const PeerAvatar({
    super.key,
    required this.peerId,
    required this.displayName,
    this.size = 48,
    this.isVerified = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = _generateColor(peerId);
    
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [color, color.withOpacity(0.7)],
        ),
        shape: BoxShape.circle,
      ),
      child: Stack(
        children: [
          Center(
            child: Text(
              displayName.isNotEmpty ? displayName[0].toUpperCase() : '?',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: size * 0.4,
              ),
            ),
          ),
          if (isVerified)
            Positioned(
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(
                  color: AppTheme.background,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.verified,
                  size: 14,
                  color: AppTheme.verified,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Color _generateColor(String seed) {
    int hash = 0;
    for (int i = 0; i < seed.length; i++) {
      hash = seed.codeUnitAt(i) + ((hash << 5) - hash);
    }
    final colors = [
      const Color(0xFF00BFA5),
      const Color(0xFF00E5FF),
      const Color(0xFF76FF03),
      const Color(0xFFFFEA00),
      const Color(0xFFFF9100),
      const Color(0xFFFF5252),
      const Color(0xFFE040FB),
      const Color(0xFF7C4DFF),
    ];
    return colors[hash.abs() % colors.length];
  }
}