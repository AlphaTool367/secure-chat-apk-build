import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class SecurityBadge extends StatelessWidget {
  final bool isVerified;
  final bool compact;

  const SecurityBadge({
    super.key,
    required this.isVerified,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    if (compact) {
      return Icon(
        isVerified ? Icons.verified : Icons.warning_amber,
        size: 14,
        color: isVerified ? AppTheme.verified : AppTheme.unverified,
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isVerified 
            ? AppTheme.verified.withOpacity(0.1) 
            : AppTheme.unverified.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isVerified ? AppTheme.verified : AppTheme.unverified,
          width: 0.5,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isVerified ? Icons.verified : Icons.warning_amber,
            size: 12,
            color: isVerified ? AppTheme.verified : AppTheme.unverified,
          ),
          const SizedBox(width: 4),
          Text(
            isVerified ? 'Verified' : 'Unverified',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: isVerified ? AppTheme.verified : AppTheme.unverified,
            ),
          ),
        ],
      ),
    );
  }
}