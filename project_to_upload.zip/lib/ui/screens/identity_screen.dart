import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme/app_theme.dart';
import '../blocs/identity_bloc.dart';
import '../widgets/peer_avatar.dart';

class IdentityScreen extends StatelessWidget {
  const IdentityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('My Identity'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined),
            onPressed: () => _shareIdentity(context),
          ),
        ],
      ),
      body: BlocBuilder<IdentityBloc, IdentityState>(
        builder: (context, state) {
          if (state is IdentityLoaded) {
            return _buildIdentityContent(context, state);
          }
          return const Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  Widget _buildIdentityContent(BuildContext context, IdentityLoaded state) {
    final identity = state.identity;
    
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(
          child: Column(
            children: [
              PeerAvatar(
                peerId: identity.anonId,
                displayName: identity.anonId,
                size: 80,
                isVerified: true,
              ),
              const SizedBox(height: 16),
              Text(
                identity.anonId,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Anonymous Identity',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppTheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 32),
        _buildSectionHeader('Fingerprint'),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.divider),
          ),
          child: Column(
            children: [
              Text(
                identity.verifyingKeyFingerprint,
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primary,
                  letterSpacing: 2,
                  height: 1.8,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              const Text(
                'Share this fingerprint so others can verify your identity',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: AppTheme.textMuted),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => _copyFingerprint(context, identity.verifyingKeyFingerprint),
                icon: const Icon(Icons.copy, size: 18),
                label: const Text('Copy Fingerprint'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        _buildSectionHeader('Backup'),
        _buildActionTile(
          icon: Icons.download,
          title: 'Export Encrypted Backup',
          subtitle: 'Save to QR code or USB',
          onTap: () => _showExportDialog(context),
        ),
        _buildActionTile(
          icon: Icons.upload,
          title: 'Restore from Backup',
          subtitle: 'Recover identity and chats',
          onTap: () => _showRestoreDialog(context),
        ),
        const SizedBox(height: 24),
        _buildSectionHeader('Danger Zone'),
        _buildActionTile(
          icon: Icons.refresh,
          title: 'Rotate Identity Keys',
          subtitle: 'Generate new keypair (old contacts need re-verification)',
          color: AppTheme.warning,
          onTap: () => _showRotateDialog(context),
        ),
        _buildActionTile(
          icon: Icons.delete_forever,
          title: 'Destroy Identity',
          subtitle: 'Permanently delete all identity data',
          color: AppTheme.error,
          onTap: () => _showDestroyDialog(context),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: AppTheme.primary,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildActionTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    Color color = AppTheme.primary,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
        trailing: const Icon(Icons.chevron_right, color: AppTheme.textMuted),
        onTap: onTap,
      ),
    );
  }

  void _copyFingerprint(BuildContext context, String fingerprint) {
    Clipboard.setData(ClipboardData(text: fingerprint));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Fingerprint copied to clipboard')),
    );
  }

  void _shareIdentity(BuildContext context) {
    // Share sheet with fingerprint and public key
  }

  void _showExportDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Export Backup', style: TextStyle(color: AppTheme.textPrimary)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Enter a strong password to encrypt your backup:',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 16),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Password',
                filled: true,
                fillColor: AppTheme.background,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              context.read<IdentityBloc>().add(ExportBackup('password'));
              Navigator.pop(context);
            },
            child: const Text('Export'),
          ),
        ],
      ),
    );
  }

  void _showRestoreDialog(BuildContext context) {
    // Show restore from QR/file dialog
  }

  void _showRotateDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Row(
          children: [
            Icon(Icons.warning, color: AppTheme.warning),
            SizedBox(width: 8),
            Text('Rotate Keys?', style: TextStyle(color: AppTheme.warning)),
          ],
        ),
        content: const Text(
          'This will generate a new identity keypair. All existing contacts will need to re-verify your identity. Your chat history will be preserved.',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              context.read<IdentityBloc>().add(GenerateNewIdentity());
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.warning),
            child: const Text('Rotate'),
          ),
        ],
      ),
    );
  }

  void _showDestroyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Row(
          children: [
            Icon(Icons.warning, color: AppTheme.error),
            SizedBox(width: 8),
            Text('Destroy Identity?', style: TextStyle(color: AppTheme.error)),
          ],
        ),
        content: const Text(
          'This will permanently destroy your anonymous identity and all associated data. You will not be able to recover your chats or contacts.',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
            child: const Text('Destroy Forever'),
          ),
        ],
      ),
    );
  }
}