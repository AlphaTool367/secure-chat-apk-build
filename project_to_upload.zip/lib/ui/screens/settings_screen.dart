import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme/app_theme.dart';
import '../../core/models/models.dart';
import '../blocs/settings_bloc.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Settings'),
      ),
      body: BlocBuilder<SettingsBloc, SettingsState>(
        builder: (context, state) {
          if (state is SettingsLoaded) {
            return _buildSettingsList(context, state.settings);
          }
          return const Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  Widget _buildSettingsList(BuildContext context, AppSettings settings) {
    return ListView(
      children: [
        _buildSectionHeader('Networking'),
        _buildSwitchTile(
          icon: Icons.bluetooth,
          title: 'BLE Direct',
          subtitle: 'Nearby peer-to-peer (10-100m)',
          value: settings.bleEnabled,
          onChanged: (v) => context.read<SettingsBloc>().add(ToggleBle(v)),
        ),
        _buildSwitchTile(
          icon: Icons.wifi_tethering,
          title: 'Wi-Fi Direct',
          subtitle: 'Local mesh networking',
          value: settings.wifiDirectEnabled,
          onChanged: (v) => context.read<SettingsBloc>().add(ToggleWifiDirect(v)),
        ),
        _buildSwitchTile(
          icon: Icons.device_hub,
          title: 'Mesh Relay',
          subtitle: 'Multi-hop community routing',
          value: settings.meshRelayEnabled,
          onChanged: (v) => context.read<SettingsBloc>().add(ToggleMesh(v)),
        ),
        _buildSwitchTile(
          icon: Icons.vpn_key,
          title: 'Tor Routing',
          subtitle: 'IP/location masking (requires TorQ plugin)',
          value: settings.torModeEnabled,
          onChanged: (v) => context.read<SettingsBloc>().add(ToggleTor(v)),
        ),
        
        _buildSectionHeader('Security'),
        _buildSwitchTile(
          icon: Icons.verified_user,
          title: 'Require Verification',
          subtitle: 'Block unverified contacts',
          value: settings.requireVerification,
          onChanged: (v) {
            final updated = settings.copyWith(requireVerification: v);
            context.read<SettingsBloc>().add(UpdateSettings(updated));
          },
        ),
        _buildSwitchTile(
          icon: Icons.no_photography,
          title: 'Screenshot Protection',
          subtitle: 'Prevent screenshots in app',
          value: settings.screenshotProtection,
          onChanged: (v) {
            final updated = settings.copyWith(screenshotProtection: v);
            context.read<SettingsBloc>().add(UpdateSettings(updated));
          },
        ),
        _buildSwitchTile(
          icon: Icons.fingerprint,
          title: 'Biometric Lock',
          subtitle: 'Require biometrics to open app',
          value: settings.biometricsRequired,
          onChanged: (v) {
            final updated = settings.copyWith(biometricsRequired: v);
            context.read<SettingsBloc>().add(UpdateSettings(updated));
          },
        ),
        
        _buildSectionHeader('Privacy'),
        ListTile(
          leading: const Icon(Icons.timer, color: AppTheme.primary),
          title: const Text(
            'Self-Destruct Timer',
            style: TextStyle(color: AppTheme.textPrimary),
          ),
          subtitle: Text(
            settings.selfDestructTimer > 0 
                ? '${settings.selfDestructTimer}s after reading'
                : 'Disabled',
            style: const TextStyle(color: AppTheme.textMuted),
          ),
          trailing: const Icon(Icons.chevron_right, color: AppTheme.textMuted),
          onTap: () => _showTimerDialog(context, settings),
        ),
        _buildSwitchTile(
          icon: Icons.local_offer,
          title: 'Metadata Stripping',
          subtitle: 'Remove EXIF from media',
          value: settings.metadataStripping,
          onChanged: (v) {
            final updated = settings.copyWith(metadataStripping: v);
            context.read<SettingsBloc>().add(UpdateSettings(updated));
          },
        ),
        
        _buildSectionHeader('Identity'),
        ListTile(
          leading: const Icon(Icons.person_outline, color: AppTheme.primary),
          title: const Text(
            'My Identity',
            style: TextStyle(color: AppTheme.textPrimary),
          ),
          subtitle: const Text(
            'View fingerprint, export backup',
            style: TextStyle(color: AppTheme.textMuted),
          ),
          trailing: const Icon(Icons.chevron_right, color: AppTheme.textMuted),
          onTap: () => Navigator.pushNamed(context, '/identity'),
        ),
        
        _buildSectionHeader('Danger Zone'),
        ListTile(
          leading: const Icon(Icons.delete_forever, color: AppTheme.error),
          title: const Text(
            'Delete All Data',
            style: TextStyle(color: AppTheme.error),
          ),
          subtitle: const Text(
            'Permanently erase all chats and identity',
            style: TextStyle(color: AppTheme.textMuted),
          ),
          onTap: () => _showDeleteConfirm(context),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: AppTheme.primary,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildSwitchTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return SwitchListTile(
      secondary: Icon(icon, color: AppTheme.primary),
      title: Text(title, style: const TextStyle(color: AppTheme.textPrimary)),
      subtitle: Text(subtitle, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
      value: value,
      onChanged: onChanged,
      activeColor: AppTheme.primary,
    );
  }

  void _showTimerDialog(BuildContext context, AppSettings settings) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Self-Destruct Timer', style: TextStyle(color: AppTheme.textPrimary)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Messages will be automatically deleted after being read:',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 16),
            _TimerOption(
              label: 'Off',
              seconds: 0,
              current: settings.selfDestructTimer,
              onSelect: (s) {
                context.read<SettingsBloc>().add(SetSelfDestructTimer(s));
                Navigator.pop(context);
              },
            ),
            _TimerOption(
              label: '5 seconds',
              seconds: 5,
              current: settings.selfDestructTimer,
              onSelect: (s) {
                context.read<SettingsBloc>().add(SetSelfDestructTimer(s));
                Navigator.pop(context);
              },
            ),
            _TimerOption(
              label: '1 minute',
              seconds: 60,
              current: settings.selfDestructTimer,
              onSelect: (s) {
                context.read<SettingsBloc>().add(SetSelfDestructTimer(s));
                Navigator.pop(context);
              },
            ),
            _TimerOption(
              label: '1 hour',
              seconds: 3600,
              current: settings.selfDestructTimer,
              onSelect: (s) {
                context.read<SettingsBloc>().add(SetSelfDestructTimer(s));
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirm(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Row(
          children: [
            Icon(Icons.warning, color: AppTheme.error),
            SizedBox(width: 8),
            Text('Delete Everything?', style: TextStyle(color: AppTheme.error)),
          ],
        ),
        content: const Text(
          'This will permanently delete all your chats, contacts, and identity. '
          'Make sure you have exported a backup first. This action cannot be undone.',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Delete all data
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
            child: const Text('Delete Forever'),
          ),
        ],
      ),
    );
  }
}

class _TimerOption extends StatelessWidget {
  final String label;
  final int seconds;
  final int current;
  final ValueChanged<int> onSelect;

  const _TimerOption({
    required this.label,
    required this.seconds,
    required this.current,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = seconds == current;
    return ListTile(
      title: Text(label, style: const TextStyle(color: AppTheme.textPrimary)),
      trailing: isSelected 
          ? const Icon(Icons.check_circle, color: AppTheme.primary)
          : const Icon(Icons.circle_outlined, color: AppTheme.textMuted),
      onTap: () => onSelect(seconds),
    );
  }
}