import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../core/models/models.dart';

abstract class SettingsEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadSettings extends SettingsEvent {}

class UpdateSettings extends SettingsEvent {
  final AppSettings settings;
  UpdateSettings(this.settings);
  @override
  List<Object?> get props => [settings];
}

class ToggleBle extends SettingsEvent {
  final bool enabled;
  ToggleBle(this.enabled);
  @override
  List<Object?> get props => [enabled];
}

class ToggleWifiDirect extends SettingsEvent {
  final bool enabled;
  ToggleWifiDirect(this.enabled);
  @override
  List<Object?> get props => [enabled];
}

class ToggleMesh extends SettingsEvent {
  final bool enabled;
  ToggleMesh(this.enabled);
  @override
  List<Object?> get props => [enabled];
}

class ToggleTor extends SettingsEvent {
  final bool enabled;
  ToggleTor(this.enabled);
  @override
  List<Object?> get props => [enabled];
}

class SetSelfDestructTimer extends SettingsEvent {
  final int seconds;
  SetSelfDestructTimer(this.seconds);
  @override
  List<Object?> get props => [seconds];
}

abstract class SettingsState extends Equatable {
  @override
  List<Object?> get props => [];
}

class SettingsInitial extends SettingsState {}

class SettingsLoading extends SettingsState {}

class SettingsLoaded extends SettingsState {
  final AppSettings settings;
  SettingsLoaded(this.settings);
  @override
  List<Object?> get props => [settings];
}

class SettingsError extends SettingsState {
  final String message;
  SettingsError(this.message);
  @override
  List<Object?> get props => [message];
}

class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  SettingsBloc() : super(SettingsInitial()) {
    on<LoadSettings>(_onLoadSettings);
    on<UpdateSettings>(_onUpdateSettings);
    on<ToggleBle>(_onToggleBle);
    on<ToggleWifiDirect>(_onToggleWifiDirect);
    on<ToggleMesh>(_onToggleMesh);
    on<ToggleTor>(_onToggleTor);
    on<SetSelfDestructTimer>(_onSetSelfDestructTimer);
  }

  AppSettings _settings = const AppSettings();

  Future<void> _onLoadSettings(LoadSettings event, Emitter<SettingsState> emit) async {
    emit(SettingsLoading());
    try {
      // Load from encrypted storage
      emit(SettingsLoaded(_settings));
    } catch (e) {
      emit(SettingsError('Failed to load settings: $e'));
    }
  }

  Future<void> _onUpdateSettings(UpdateSettings event, Emitter<SettingsState> emit) async {
    _settings = event.settings;
    await _saveSettings();
    emit(SettingsLoaded(_settings));
  }

  Future<void> _onToggleBle(ToggleBle event, Emitter<SettingsState> emit) async {
    _settings = _settings.copyWith(bleEnabled: event.enabled);
    await _saveSettings();
    emit(SettingsLoaded(_settings));
  }

  Future<void> _onToggleWifiDirect(ToggleWifiDirect event, Emitter<SettingsState> emit) async {
    _settings = _settings.copyWith(wifiDirectEnabled: event.enabled);
    await _saveSettings();
    emit(SettingsLoaded(_settings));
  }

  Future<void> _onToggleMesh(ToggleMesh event, Emitter<SettingsState> emit) async {
    _settings = _settings.copyWith(meshRelayEnabled: event.enabled);
    await _saveSettings();
    emit(SettingsLoaded(_settings));
  }

  Future<void> _onToggleTor(ToggleTor event, Emitter<SettingsState> emit) async {
    _settings = _settings.copyWith(torModeEnabled: event.enabled);
    await _saveSettings();
    emit(SettingsLoaded(_settings));
  }

  Future<void> _onSetSelfDestructTimer(SetSelfDestructTimer event, Emitter<SettingsState> emit) async {
    _settings = _settings.copyWith(selfDestructTimer: event.seconds);
    await _saveSettings();
    emit(SettingsLoaded(_settings));
  }

  Future<void> _saveSettings() async {
    // Persist to encrypted storage
  }
}