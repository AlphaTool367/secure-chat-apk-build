import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../core/models/models.dart';

abstract class ChatEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadChats extends ChatEvent {}

class LoadMessages extends ChatEvent {
  final String peerId;
  LoadMessages(this.peerId);
  @override
  List<Object?> get props => [peerId];
}

class SendMessage extends ChatEvent {
  final String peerId;
  final String content;
  final MessageType type;
  SendMessage({required this.peerId, required this.content, this.type = MessageType.text});
  @override
  List<Object?> get props => [peerId, content, type];
}

class MessageReceived extends ChatEvent {
  final String peerId;
  final ChatMessage message;
  MessageReceived({required this.peerId, required this.message});
  @override
  List<Object?> get props => [peerId, message];
}

class MarkAsRead extends ChatEvent {
  final String peerId;
  final List<String> messageIds;
  MarkAsRead({required this.peerId, required this.messageIds});
  @override
  List<Object?> get props => [peerId, messageIds];
}

abstract class ChatState extends Equatable {
  @override
  List<Object?> get props => [];
}

class ChatInitial extends ChatState {}

class ChatsLoading extends ChatState {}

class ChatsLoaded extends ChatState {
  final List<Chat> chats;
  ChatsLoaded(this.chats);
  @override
  List<Object?> get props => [chats];
}

class MessagesLoading extends ChatState {
  final String peerId;
  MessagesLoading(this.peerId);
  @override
  List<Object?> get props => [peerId];
}

class MessagesLoaded extends ChatState {
  final String peerId;
  final List<ChatMessage> messages;
  MessagesLoaded({required this.peerId, required this.messages});
  @override
  List<Object?> get props => [peerId, messages];
}

class ChatError extends ChatState {
  final String message;
  ChatError(this.message);
  @override
  List<Object?> get props => [message];
}

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  ChatBloc() : super(ChatInitial()) {
    on<LoadChats>(_onLoadChats);
    on<LoadMessages>(_onLoadMessages);
    on<SendMessage>(_onSendMessage);
    on<MessageReceived>(_onMessageReceived);
    on<MarkAsRead>(_onMarkAsRead);
  }

  final List<Chat> _chats = [];
  final Map<String, List<ChatMessage>> _messages = {};

  Future<void> _onLoadChats(LoadChats event, Emitter<ChatState> emit) async {
    emit(ChatsLoading());
    try {
      // Load from storage
      emit(ChatsLoaded(List.from(_chats)));
    } catch (e) {
      emit(ChatError('Failed to load chats: $e'));
    }
  }

  Future<void> _onLoadMessages(LoadMessages event, Emitter<ChatState> emit) async {
    emit(MessagesLoading(event.peerId));
    try {
      final messages = _messages[event.peerId] ?? [];
      emit(MessagesLoaded(peerId: event.peerId, messages: messages));
    } catch (e) {
      emit(ChatError('Failed to load messages: $e'));
    }
  }

  Future<void> _onSendMessage(SendMessage event, Emitter<ChatState> emit) async {
    try {
      final message = ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        senderId: 'self',
        content: event.content,
        timestamp: DateTime.now(),
        direction: MessageDirection.outgoing,
        type: event.type,
      );
      
      _messages[event.peerId] = [...(_messages[event.peerId] ?? []), message];
      
      emit(MessagesLoaded(
        peerId: event.peerId,
        messages: _messages[event.peerId]!,
      ));
    } catch (e) {
      emit(ChatError('Failed to send: $e'));
    }
  }

  Future<void> _onMessageReceived(MessageReceived event, Emitter<ChatState> emit) async {
    _messages[event.peerId] = [...(_messages[event.peerId] ?? []), event.message];
    
    emit(MessagesLoaded(
      peerId: event.peerId,
      messages: _messages[event.peerId]!,
    ));
  }

  Future<void> _onMarkAsRead(MarkAsRead event, Emitter<ChatState> emit) async {
    // Update read status
  }
}
